#!/usr/bin/env python
"""
BioShield AI – Startup Script
Launches the Flask web server with automatic environment variable setup.
"""
import os
import sys

# Ensure UTF-8 output across all consoles
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

# Ensure project root is in python path
current_dir = os.path.abspath(os.path.dirname(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from config import HOST, PORT, DEBUG
from app import app

if __name__ == "__main__":
    print("=" * 65)
    print("  [BioShield AI] Intelligent Biometric Authentication System")
    print("=" * 65)
    print(f"  * Web Interface:    http://{HOST}:{PORT}")
    print(f"  * Live Kiosk:       http://{HOST}:{PORT}/authenticate")
    print(f"  * User Enrollment:  http://{HOST}:{PORT}/register")
    print(f"  * Admin Dashboard:  http://{HOST}:{PORT}/dashboard")
    print(f"  * Security Logs:    http://{HOST}:{PORT}/logs")
    print("=" * 65)
    print("  Server is live and listening for connections...\n")

    app.run(host=HOST, port=PORT, debug=DEBUG)
