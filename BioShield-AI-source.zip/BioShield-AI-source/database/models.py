import json
import sqlite3
import numpy as np
from database.db import get_db_connection

class UserModel:
    @staticmethod
    def create(user_id, full_name, email, department, role, photo_path, embedding):
        """Creates a new registered biometric user."""
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Serialize numpy embedding array to JSON string
        if isinstance(embedding, np.ndarray):
            embedding = embedding.tolist()
        embedding_json = json.dumps(embedding)

        try:
            cursor.execute('''
                INSERT INTO users (user_id, full_name, email, department, role, photo_path, embedding, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)
            ''', (user_id, full_name, email, department, role, photo_path, embedding_json))
            conn.commit()
            new_id = cursor.lastrowid
            return new_id
        except sqlite3.IntegrityError as e:
            return None
        finally:
            conn.close()

    @staticmethod
    def get_all(include_inactive=True):
        """Retrieves all registered users for administration."""
        conn = get_db_connection()
        cursor = conn.cursor()
        if include_inactive:
            cursor.execute('SELECT id, user_id, full_name, email, department, role, photo_path, is_active, created_at FROM users ORDER BY created_at DESC')
        else:
            cursor.execute('SELECT id, user_id, full_name, email, department, role, photo_path, is_active, created_at FROM users WHERE is_active = 1 ORDER BY created_at DESC')
        rows = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return rows

    @staticmethod
    def get_all_active_embeddings():
        """Retrieves all active users with their deserialized numpy embedding vectors."""
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT id, user_id, full_name, department, role, photo_path, embedding FROM users WHERE is_active = 1')
        rows = cursor.fetchall()
        conn.close()

        users_with_embeddings = []
        for r in rows:
            try:
                emb_list = json.loads(r['embedding'])
                emb_vec = np.array(emb_list, dtype=np.float32)
                users_with_embeddings.append({
                    'id': r['id'],
                    'user_id': r['user_id'],
                    'full_name': r['full_name'],
                    'department': r['department'],
                    'role': r['role'],
                    'photo_path': r['photo_path'],
                    'embedding': emb_vec
                })
            except Exception as e:
                print(f"[Error] Failed to parse embedding for user {r['user_id']}: {e}")
        return users_with_embeddings

    @staticmethod
    def get_by_user_id(user_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    @staticmethod
    def toggle_status(user_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('UPDATE users SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE user_id = ?', (user_id,))
        conn.commit()
        updated = cursor.rowcount > 0
        conn.close()
        return updated

    @staticmethod
    def delete(user_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM users WHERE user_id = ?', (user_id,))
        conn.commit()
        deleted = cursor.rowcount > 0
        conn.close()
        return deleted


class SecurityLogModel:
    @staticmethod
    def log(user_id, user_name, status, reason, confidence_score=0.0, liveness_score=0.0, spoof_score=0.0, snapshot_path=None, ip_address='127.0.0.1', challenge_details=None):
        """Records a biometric authentication attempt into the security audit ledger."""
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO security_logs (
                user_id, user_name, status, reason,
                confidence_score, liveness_score, spoof_score,
                snapshot_path, ip_address, challenge_details
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            user_id, user_name, status, reason,
            float(confidence_score), float(liveness_score), float(spoof_score),
            snapshot_path, ip_address,
            json.dumps(challenge_details) if isinstance(challenge_details, (dict, list)) else challenge_details
        ))
        conn.commit()
        log_id = cursor.lastrowid
        conn.close()
        return log_id

    @staticmethod
    def get_recent(limit=50, status_filter=None, search=None):
        """Fetches security audit logs with optional filters."""
        conn = get_db_connection()
        cursor = conn.cursor()

        query = 'SELECT * FROM security_logs WHERE 1=1'
        params = []

        if status_filter and status_filter != 'ALL':
            query += ' AND status = ?'
            params.append(status_filter)

        if search:
            query += ' AND (user_name LIKE ? OR user_id LIKE ? OR reason LIKE ?)'
            search_param = f"%{search}%"
            params.extend([search_param, search_param, search_param])

        query += ' ORDER BY timestamp DESC LIMIT ?'
        params.append(limit)

        cursor.execute(query, tuple(params))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    @staticmethod
    def get_analytics():
        """Computes executive security statistics for the Admin Dashboard."""
        conn = get_db_connection()
        cursor = conn.cursor()

        # User counts
        cursor.execute('SELECT COUNT(*) FROM users')
        total_users = cursor.fetchone()[0]

        cursor.execute('SELECT COUNT(*) FROM users WHERE is_active = 1')
        active_users = cursor.fetchone()[0]

        # Log statistics
        cursor.execute('SELECT COUNT(*) FROM security_logs')
        total_attempts = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM security_logs WHERE status = 'GRANTED'")
        granted_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM security_logs WHERE status = 'SPOOF_DETECTED'")
        spoof_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM security_logs WHERE status = 'LIVENESS_FAILED'")
        liveness_failed_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM security_logs WHERE status = 'DENIED'")
        denied_count = cursor.fetchone()[0]

        # Today's attempts
        cursor.execute("SELECT COUNT(*) FROM security_logs WHERE date(timestamp) = date('now')")
        today_attempts = cursor.fetchone()[0]

        success_rate = round((granted_count / total_attempts * 100), 1) if total_attempts > 0 else 0.0

        # Distribution breakdown for chart
        breakdown = {
            'granted': granted_count,
            'spoof_detected': spoof_count,
            'liveness_failed': liveness_failed_count,
            'denied': denied_count
        }

        # Hourly / recent status timeline
        cursor.execute('''
            SELECT status, strftime('%H:00', timestamp) as hour, COUNT(*) as count
            FROM security_logs
            WHERE date(timestamp) = date('now')
            GROUP BY status, hour
            ORDER BY hour ASC
        ''')
        hourly_rows = [dict(r) for r in cursor.fetchall()]

        conn.close()

        return {
            'total_users': total_users,
            'active_users': active_users,
            'total_attempts': total_attempts,
            'granted_count': granted_count,
            'spoof_count': spoof_count,
            'liveness_failed_count': liveness_failed_count,
            'denied_count': denied_count,
            'today_attempts': today_attempts,
            'success_rate': success_rate,
            'breakdown': breakdown,
            'hourly': hourly_rows
        }


class TaskModel:
    @staticmethod
    def create(task_id, user_id, title, description="", priority="MEDIUM", due_date="Today"):
        """Assigns an operational task to a specific biometric user/employee."""
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO tasks (task_id, user_id, title, description, priority, status, due_date)
                VALUES (?, ?, ?, ?, ?, 'PENDING', ?)
            ''', (task_id, user_id, title, description, priority.upper(), due_date))
            conn.commit()
            new_id = cursor.lastrowid
            return new_id
        except sqlite3.IntegrityError:
            return None
        finally:
            conn.close()

    @staticmethod
    def get_by_user_id(user_id, status=None):
        """Retrieves assigned tasks unlocked for an authenticated employee."""
        conn = get_db_connection()
        cursor = conn.cursor()
        query = "SELECT * FROM tasks WHERE user_id = ?"
        params = [user_id]
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY CASE priority WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'MEDIUM' THEN 3 ELSE 4 END, created_at DESC"
        cursor.execute(query, tuple(params))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    @staticmethod
    def get_all():
        """Fetches all tasks joined with assigned user details for admin management."""
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT t.*, u.full_name as assignee_name, u.department as assignee_dept, u.photo_path as assignee_photo
            FROM tasks t
            LEFT JOIN users u ON t.user_id = u.user_id
            ORDER BY t.created_at DESC
        ''')
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    @staticmethod
    def update_status(task_id, new_status):
        """Updates task progress (PENDING, IN_PROGRESS, COMPLETED)."""
        conn = get_db_connection()
        cursor = conn.cursor()
        if new_status == "COMPLETED":
            cursor.execute("UPDATE tasks SET status = ?, completed_at = CURRENT_TIMESTAMP WHERE task_id = ?", (new_status, task_id))
        else:
            cursor.execute("UPDATE tasks SET status = ? WHERE task_id = ?", (new_status, task_id))
        conn.commit()
        updated = cursor.rowcount > 0
        conn.close()
        return updated

    @staticmethod
    def delete(task_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM tasks WHERE task_id = ?", (task_id,))
        conn.commit()
        deleted = cursor.rowcount > 0
        conn.close()
        return deleted

