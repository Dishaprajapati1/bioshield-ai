import sqlite3
import os
import json
from config import DATABASE_PATH

def get_db_connection():
    """Establishes and returns an SQLite database connection with row factory."""
    conn = sqlite3.connect(DATABASE_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initializes tables and schema for BioShield AI."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Users table: holds registered biometric profiles & embeddings
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT UNIQUE NOT NULL,
            full_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            department TEXT DEFAULT 'General',
            role TEXT DEFAULT 'User',
            photo_path TEXT NOT NULL,
            embedding TEXT NOT NULL,
            is_active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Security logs table: captures every biometric authentication attempt & audit trail
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS security_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            user_name TEXT,
            status TEXT NOT NULL,
            reason TEXT,
            confidence_score REAL DEFAULT 0.0,
            liveness_score REAL DEFAULT 0.0,
            spoof_score REAL DEFAULT 0.0,
            snapshot_path TEXT,
            ip_address TEXT DEFAULT '127.0.0.1',
            challenge_details TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Tasks table: Biometric-Gated Task Authorization for specific employees
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id TEXT UNIQUE NOT NULL,
            user_id TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            priority TEXT DEFAULT 'MEDIUM',
            status TEXT DEFAULT 'PENDING',
            due_date TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP
        )
    ''')

    # Indexes for fast querying
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON security_logs(timestamp DESC)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_logs_status ON security_logs(status)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_users_active ON users(is_active)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks(user_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)')

    conn.commit()
    conn.close()
    print("[Database] Schema initialized successfully at:", DATABASE_PATH)

if __name__ == "__main__":
    init_db()
