/**
 * BioShield AI – Admin Dashboard Charts & Interactions
 */

document.addEventListener("DOMContentLoaded", () => {
  initCharts();
  initUserTableControls();
  initTaskControls();
  initDiagnosticSandbox();
});

function initCharts() {
  const analytics = window.dashboardAnalytics || {};
  const breakdown = analytics.breakdown || {
    granted: 0,
    spoof_detected: 0,
    liveness_failed: 0,
    denied: 0
  };

  // 1. Outcomes Doughnut Chart
  const outcomesCtx = document.getElementById("outcomesChart");
  if (outcomesCtx) {
    new Chart(outcomesCtx, {
      type: "doughnut",
      data: {
        labels: ["Granted", "Spoof Blocked", "Liveness Failed", "Denied / Unrec."],
        datasets: [{
          data: [
            breakdown.granted || 0,
            breakdown.spoof_detected || 0,
            breakdown.liveness_failed || 0,
            breakdown.denied || 0
          ],
          backgroundColor: [
            "#10b981", // Emerald
            "#f43f5e", // Rose
            "#f59e0b", // Amber
            "#64748b"  // Slate
          ],
          borderWidth: 2,
          borderColor: "#0f172a"
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "bottom",
            labels: { color: "#94a3b8", boxWidth: 12, padding: 15 }
          }
        },
        cutout: "70%"
      }
    });
  }

  // 2. Activity Breakdown Bar Chart
  const activityCtx = document.getElementById("activityChart");
  if (activityCtx) {
    new Chart(activityCtx, {
      type: "bar",
      data: {
        labels: ["Granted Access", "Spoof Attacks", "Liveness Timeouts", "Unrecognized"],
        datasets: [{
          label: "Attempts Count",
          data: [
            breakdown.granted || 0,
            breakdown.spoof_detected || 0,
            breakdown.liveness_failed || 0,
            breakdown.denied || 0
          ],
          backgroundColor: [
            "rgba(16, 185, 129, 0.4)",
            "rgba(244, 63, 94, 0.4)",
            "rgba(245, 158, 11, 0.4)",
            "rgba(100, 116, 139, 0.4)"
          ],
          borderColor: [
            "#10b981",
            "#f43f5e",
            "#f59e0b",
            "#64748b"
          ],
          borderWidth: 1.5,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            grid: { display: false },
            ticks: { color: "#94a3b8" }
          },
          y: {
            beginAtZero: true,
            grid: { color: "rgba(56, 189, 248, 0.08)" },
            ticks: { color: "#94a3b8", stepSize: 1 }
          }
        },
        plugins: {
          legend: { display: false }
        }
      }
    });
  }
}

function initUserTableControls() {
  // Search filter
  const searchInput = document.getElementById("userTableSearch");
  const usersTable = document.getElementById("usersTable");

  if (searchInput && usersTable) {
    searchInput.addEventListener("input", (e) => {
      const q = e.target.value.toLowerCase();
      const rows = usersTable.querySelectorAll("tbody tr");
      rows.forEach(r => {
        const text = r.innerText.toLowerCase();
        r.style.display = text.includes(q) ? "" : "none";
      });
    });
  }

  // Toggle user status
  document.querySelectorAll(".toggle-user-btn").forEach(btn => {
    btn.addEventListener("click", async () => {
      const userId = btn.getAttribute("data-user-id");
      try {
        const res = await fetch(`/api/users/${userId}/toggle`, { method: "POST" });
        const data = await res.json();
        if (data.success) {
          window.location.reload();
        } else {
          alert("Failed to toggle user status.");
        }
      } catch (err) {
        console.error(err);
      }
    });
  });

  // Delete user
  document.querySelectorAll(".delete-user-btn").forEach(btn => {
    btn.addEventListener("click", async () => {
      const userId = btn.getAttribute("data-user-id");
      if (!confirm(`Are you sure you want to permanently delete biometric profile for ${userId}?`)) return;

      try {
        const res = await fetch(`/api/users/${userId}`, { method: "DELETE" });
        const data = await res.json();
        if (data.success) {
          const row = document.querySelector(`tr[data-user-id="${userId}"]`);
          if (row) row.remove();
        } else {
          alert("Failed to delete user.");
        }
      } catch (err) {
        console.error(err);
      }
    });
  });
}

function initTaskControls() {
  const assignForm = document.getElementById("assignTaskForm");
  const modalEl = document.getElementById("assignTaskModal");

  if (assignForm) {
    assignForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const payload = {
        user_id: document.getElementById("taskTargetUser").value,
        title: document.getElementById("taskTitleInput").value.trim(),
        description: document.getElementById("taskDescInput").value.trim(),
        priority: document.getElementById("taskPriorityInput").value,
        due_date: document.getElementById("taskDueDateInput").value.trim()
      };

      try {
        const resp = await fetch("/api/tasks", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        const res = await resp.json();
        if (res.success) {
          const bsModal = bootstrap.Modal.getInstance(modalEl);
          if (bsModal) bsModal.hide();
          window.location.reload();
        } else {
          alert("Error: " + (res.error || "Could not assign task"));
        }
      } catch (err) {
        console.error("Task assignment error:", err);
      }
    });
  }

  // Delete task
  document.querySelectorAll(".delete-task-btn").forEach(btn => {
    btn.addEventListener("click", async () => {
      const taskId = btn.getAttribute("data-task-id");
      if (!confirm(`Delete task ${taskId}?`)) return;

      try {
        const resp = await fetch(`/api/tasks/${taskId}`, { method: "DELETE" });
        const res = await resp.json();
        if (res.success) {
          const row = document.getElementById(`admin-task-row-${taskId}`);
          if (row) row.remove();
        } else {
          alert("Failed to delete task.");
        }
      } catch (err) {
        console.error(err);
      }
    });
  });
}

function initDiagnosticSandbox() {
  const fileInput = document.getElementById("sandboxFileInput");
  const resultBox = document.getElementById("sandboxResult");
  const verdictBadge = document.getElementById("sandboxVerdict");
  const diagLaplacian = document.getElementById("diagLaplacian");
  const diagFFT = document.getElementById("diagFFT");
  const diagColor = document.getElementById("diagColor");
  const diagGlare = document.getElementById("diagGlare");

  if (!fileInput) return;

  fileInput.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = reader.result;

      resultBox.style.display = "block";
      verdictBadge.className = "badge badge-neon-amber";
      verdictBadge.innerText = "Analyzing Frequencies...";

      try {
        const resp = await fetch("/api/test/anti-spoof", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ image: base64Data })
        });

        const res = await resp.json();
        if (!res.success) throw new Error(res.error || "Analysis failed");

        const m = res.metrics;
        diagLaplacian.innerText = m.laplacian_variance !== undefined ? m.laplacian_variance : "--";
        diagFFT.innerText = m.fft_moiré_score !== undefined ? m.fft_moiré_score : "--";
        diagColor.innerText = m.color_diversity !== undefined ? m.color_diversity : "--";
        diagGlare.innerText = m.glare_index !== undefined ? `${(m.glare_index * 100).toFixed(1)}%` : "--";

        if (res.is_real) {
          verdictBadge.className = "badge badge-neon-emerald";
          verdictBadge.innerText = "GENUINE LIVE FACE";
        } else {
          verdictBadge.className = "badge badge-neon-rose";
          verdictBadge.innerText = `SPOOF DETECTED (${(res.spoof_score * 100).toFixed(0)}%)`;
        }

      } catch (err) {
        verdictBadge.className = "badge bg-danger text-white";
        verdictBadge.innerText = "Analysis Error";
        console.error(err);
      }
    };

    reader.readAsDataURL(file);
  });
}
