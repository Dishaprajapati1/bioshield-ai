/**
 * BioShield AI – Biometric User Registration Script
 */

class UserEnrollmentController {
  constructor() {
    this.video = document.getElementById("regWebcam");
    this.canvas = document.getElementById("regCanvas");
    this.ctx = this.canvas.getContext("2d");
    
    this.placeholder = document.getElementById("regPlaceholder");
    this.previewImg = document.getElementById("capturedPreviewImg");
    this.guideOval = document.getElementById("regGuideOval");
    this.statusBadge = document.getElementById("regStatusBadge");
    
    this.btnStart = document.getElementById("btnStartRegCamera");
    this.btnSnap = document.getElementById("btnSnapFace");
    this.btnRetake = document.getElementById("btnRetakeFace");
    this.btnSubmit = document.getElementById("btnSubmitEnrollment");

    this.form = document.getElementById("enrollmentForm");
    this.inputUserId = document.getElementById("inputUserId");
    this.inputFullName = document.getElementById("inputFullName");
    this.inputEmail = document.getElementById("inputEmail");
    this.inputDepartment = document.getElementById("inputDepartment");
    this.inputRole = document.getElementById("inputRole");

    this.chkFace = document.getElementById("chkFace");
    this.chkAntiSpoof = document.getElementById("chkAntiSpoof");
    this.chkEmbedding = document.getElementById("chkEmbedding");
    this.alertBox = document.getElementById("enrollmentAlert");

    this.stream = null;
    this.capturedBase64 = null;

    this.bindEvents();
  }

  bindEvents() {
    if (this.btnStart) this.btnStart.addEventListener("click", () => this.startCamera());
    if (this.btnSnap) this.btnSnap.addEventListener("click", () => this.snapPortrait());
    if (this.btnRetake) this.btnRetake.addEventListener("click", () => this.retakePortrait());
    if (this.form) this.form.addEventListener("submit", (e) => this.submitEnrollment(e));
  }

  async startCamera() {
    try {
      this.statusBadge.className = "badge badge-neon-amber small";
      this.statusBadge.innerText = "Connecting...";

      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, facingMode: "user" },
        audio: false
      });
      this.video.srcObject = this.stream;
      await this.video.play();

      this.placeholder.style.display = "none";
      this.btnSnap.style.display = "inline-block";
      this.statusBadge.className = "badge badge-neon-emerald small";
      this.statusBadge.innerText = "Live Feed Active";
      this.guideOval.className = "hud-guide-oval active";

    } catch (err) {
      console.error("Camera error:", err);
      alert("Could not access camera: " + err.message);
      this.statusBadge.className = "badge badge-neon-rose small";
      this.statusBadge.innerText = "Camera Denied";
    }
  }

  snapPortrait() {
    if (!this.video || this.video.videoWidth === 0) return;

    const offCanvas = document.createElement("canvas");
    offCanvas.width = this.video.videoWidth;
    offCanvas.height = this.video.videoHeight;
    const offCtx = offCanvas.getContext("2d");
    offCtx.drawImage(this.video, 0, 0);

    this.capturedBase64 = offCanvas.toDataURL("image/jpeg", 0.92);

    // Display captured snapshot in UI
    this.previewImg.src = this.capturedBase64;
    this.previewImg.style.display = "block";
    this.video.style.display = "none";

    this.btnSnap.style.display = "none";
    this.btnRetake.style.display = "inline-block";

    this.statusBadge.className = "badge badge-neon-cyan small";
    this.statusBadge.innerText = "Portrait Captured";

    // Update validation pills
    this.chkFace.className = "text-info";
    this.chkFace.innerText = "Captured & Ready";
    this.chkAntiSpoof.className = "text-info";
    this.chkAntiSpoof.innerText = "Validating on enrollment";
    this.chkEmbedding.className = "text-info";
    this.chkEmbedding.innerText = "Generating 512-D vector";
  }

  retakePortrait() {
    this.capturedBase64 = null;
    this.previewImg.style.display = "none";
    this.video.style.display = "block";

    this.btnSnap.style.display = "inline-block";
    this.btnRetake.style.display = "none";

    this.statusBadge.className = "badge badge-neon-emerald small";
    this.statusBadge.innerText = "Live Feed Active";

    this.chkFace.className = "text-warning";
    this.chkFace.innerText = "Pending Capture";
    this.chkAntiSpoof.className = "text-warning";
    this.chkAntiSpoof.innerText = "Pending Capture";
    this.chkEmbedding.className = "text-warning";
    this.chkEmbedding.innerText = "Pending Capture";
  }

  async submitEnrollment(e) {
    e.preventDefault();

    if (!this.capturedBase64) {
      this.showAlert("Please capture a live facial portrait first!", "danger");
      return;
    }

    const payload = {
      user_id: this.inputUserId.value.trim(),
      full_name: this.inputFullName.value.trim(),
      email: this.inputEmail.value.trim(),
      department: this.inputDepartment.value,
      role: this.inputRole.value,
      image: this.capturedBase64
    };

    this.btnSubmit.disabled = true;
    this.btnSubmit.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span> Enrolling Biometric Vector...`;

    try {
      const resp = await fetch("/api/users/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const res = await resp.json();

      if (res.success) {
        this.chkFace.className = "text-success fw-bold";
        this.chkFace.innerText = "Passed ✓";
        this.chkAntiSpoof.className = "text-success fw-bold";
        this.chkAntiSpoof.innerText = "Genuine Skin Verified ✓";
        this.chkEmbedding.className = "text-success fw-bold";
        this.chkEmbedding.innerText = "512-D Embedding Stored ✓";

        this.showAlert(`
          <strong>Success!</strong> ${res.message} <br>
          <div class="mt-2">
            <a href="/authenticate" class="btn btn-sm btn-success me-2"><i class="bi bi-camera-video me-1"></i> Test Authentication Now</a>
            <a href="/dashboard" class="btn btn-sm btn-outline-light"><i class="bi bi-speedometer2 me-1"></i> View in Dashboard</a>
          </div>
        `, "success");

        this.form.reset();
        this.retakePortrait();

      } else {
        this.showAlert(`<strong>Enrollment Failed:</strong> ${res.error}`, "danger");
      }

    } catch (err) {
      console.error("Enrollment error:", err);
      this.showAlert(`Server error during enrollment: ${err.message}`, "danger");
    } finally {
      this.btnSubmit.disabled = false;
      this.btnSubmit.innerHTML = `<i class="bi bi-fingerprint me-2"></i> Enroll Biometric Identity`;
    }
  }

  showAlert(html, type) {
    this.alertBox.className = `alert alert-${type === 'success' ? 'success' : 'danger'} mt-3 small`;
    this.alertBox.innerHTML = html;
    this.alertBox.style.display = "block";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  new UserEnrollmentController();
});
