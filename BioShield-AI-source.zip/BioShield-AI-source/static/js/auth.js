/**
 * BioShield AI – Client-Side Biometric Authentication & Challenge Controller
 */

class BiometricAuthenticator {
  constructor() {
    this.video = document.getElementById("webcam");
    this.canvas = document.getElementById("overlayCanvas");
    this.ctx = this.canvas.getContext("2d");
    
    // UI Elements
    this.placeholder = document.getElementById("cameraPlaceholder");
    this.scannerLine = document.getElementById("scannerLine");
    this.guideOval = document.getElementById("guideOval");
    this.challengeBanner = document.getElementById("challengeBanner");
    this.stepCounter = document.getElementById("stepCounter");
    this.challengeTitle = document.getElementById("challengeTitle");
    this.challengeInstruction = document.getElementById("challengeInstruction");
    this.challengeIcon = document.getElementById("challengeIcon");
    this.actionProgress = document.getElementById("actionProgress");
    this.actionFeedbackText = document.getElementById("actionFeedbackText");
    this.actionScoreMetric = document.getElementById("actionScoreMetric");
    
    this.telemetryStatus = document.getElementById("telemetryStatus");
    this.telemetryPose = document.getElementById("telemetryPose");
    this.telemetrySpoof = document.getElementById("telemetrySpoof");
    
    this.timerContainer = document.getElementById("timerContainer");
    this.countdownText = document.getElementById("countdownText");
    this.systemStatusBadge = document.getElementById("systemStatusBadge");

    // Result Elements
    this.resultCard = document.getElementById("resultCard");
    this.resultIconContainer = document.getElementById("resultIconContainer");
    this.resultTitle = document.getElementById("resultTitle");
    this.resultSubtitle = document.getElementById("resultSubtitle");
    this.resultUserProfile = document.getElementById("resultUserProfile");
    this.resultUserName = document.getElementById("resultUserName");
    this.resultUserId = document.getElementById("resultUserId");
    this.resultUserDept = document.getElementById("resultUserDept");
    this.resultUserPhoto = document.getElementById("resultUserPhoto");
    this.resultSpoofAlert = document.getElementById("resultSpoofAlert");
    this.resultSpoofReason = document.getElementById("resultSpoofReason");
    this.metricConfidence = document.getElementById("metricConfidence");
    this.metricDistance = document.getElementById("metricDistance");
    this.metricSpoof = document.getElementById("metricSpoof");
    this.metricLiveness = document.getElementById("metricLiveness");

    // Buttons
    this.btnStart = document.getElementById("btnStartScan");
    this.btnRestart = document.getElementById("btnRestart");
    this.btnStop = document.getElementById("btnStopCamera");
    this.btnTryAgain = document.getElementById("btnTryAgain");

    // State Variables
    this.stream = null;
    this.sessionId = null;
    this.sessionData = null;
    this.isProcessing = false;
    this.scanInterval = null;
    this.timerInterval = null;
    this.secondsRemaining = 15;

    this.bindEvents();
  }

  bindEvents() {
    if (this.btnStart) this.btnStart.addEventListener("click", () => this.startScan());
    if (this.btnRestart) this.btnRestart.addEventListener("click", () => this.startScan());
    if (this.btnStop) this.btnStop.addEventListener("click", () => this.stopCamera());
    if (this.btnTryAgain) this.btnTryAgain.addEventListener("click", () => this.startScan());
  }

  async startScan() {
    this.resetUI();
    this.updateStatusBadge("Connecting Camera...", "badge-neon-amber");

    try {
      if (!this.stream) {
        this.stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480, facingMode: "user" },
          audio: false
        });
        this.video.srcObject = this.stream;
        await this.video.play();
      }

      this.placeholder.style.display = "none";
      this.scannerLine.style.display = "block";
      this.challengeBanner.style.display = "block";
      this.btnRestart.style.display = "inline-block";
      this.btnStop.style.display = "inline-block";
      this.telemetryPose.style.display = "block";
      this.telemetrySpoof.style.display = "block";

      this.canvas.width = this.video.videoWidth || 640;
      this.canvas.height = this.video.videoHeight || 480;

      // Request new randomized challenge session from server
      await this.initSession();

    } catch (err) {
      console.error("Camera access error:", err);
      alert("Unable to access webcam. Please verify browser camera permissions: " + err.message);
      this.resetUI();
    }
  }

  async initSession() {
    try {
      this.updateStatusBadge("Generating Challenge...", "badge-neon-cyan");
      const resp = await fetch("/api/auth/start-challenge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ challenge_count: 2 })
      });

      const data = await resp.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to initialize challenge");
      }

      this.sessionId = data.session_id;
      this.sessionData = data;
      this.secondsRemaining = 15;
      
      this.timerContainer.style.display = "block";
      this.startCountdown();
      this.updateChallengeUI(0);

      this.updateStatusBadge("Liveness Verification", "badge-neon-emerald");
      this.telemetryStatus.innerText = "MODE: VERIFYING_LIVENESS";

      // Start continuous frame processing loop (every 220ms)
      this.scanInterval = setInterval(() => this.processFrame(), 220);

    } catch (err) {
      console.error("Session init error:", err);
      alert("Error starting challenge: " + err.message);
    }
  }

  startCountdown() {
    clearInterval(this.timerInterval);
    this.countdownText.innerText = `${this.secondsRemaining}s`;

    this.timerInterval = setInterval(() => {
      this.secondsRemaining--;
      this.countdownText.innerText = `${this.secondsRemaining}s`;

      if (this.secondsRemaining <= 5) {
        this.countdownText.parentElement.className = "badge bg-danger text-white fs-6 px-3 py-2";
      }

      if (this.secondsRemaining <= 0) {
        clearInterval(this.timerInterval);
        this.handleTimeout();
      }
    }, 1000);
  }

  updateChallengeUI(stepIdx) {
    if (!this.sessionData || !this.sessionData.challenges[stepIdx]) return;

    const ch = this.sessionData.challenges[stepIdx];
    this.stepCounter.innerText = `Challenge ${stepIdx + 1} of ${this.sessionData.total_steps}`;
    this.challengeTitle.innerText = ch.title;
    this.challengeInstruction.innerText = ch.instruction;
    this.challengeIcon.className = `bi ${ch.icon} challenge-icon`;
    this.actionProgress.style.width = "0%";
    this.actionFeedbackText.innerText = "Please perform the action requested above...";
  }

  captureFrameBase64() {
    if (!this.video || this.video.videoWidth === 0) return null;
    const offCanvas = document.createElement("canvas");
    offCanvas.width = this.video.videoWidth;
    offCanvas.height = this.video.videoHeight;
    const offCtx = offCanvas.getContext("2d");
    offCtx.drawImage(this.video, 0, 0);
    return offCanvas.toDataURL("image/jpeg", 0.85);
  }

  async processFrame() {
    if (this.isProcessing || !this.sessionId) return;
    this.isProcessing = true;

    try {
      const frameBase64 = this.captureFrameBase64();
      if (!frameBase64) {
        this.isProcessing = false;
        return;
      }

      const resp = await fetch("/api/auth/verify-step", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          session_id: this.sessionId,
          image: frameBase64
        })
      });

      const res = await resp.json();

      if (res.expired) {
        this.handleTimeout();
        return;
      }

      // Check for spoof attack
      if (res.spoof_detected) {
        this.handleSpoofAlert(res);
        return;
      }

      // Draw bounding box & telemetry
      this.renderHUD(res);

      if (res.has_face) {
        this.guideOval.className = "hud-guide-oval active";

        if (res.message) {
          this.actionFeedbackText.innerText = res.message;
        }

        // Action progress animation
        if (res.action_verified) {
          this.actionProgress.style.width = "100%";
          this.actionProgress.className = "progress-bar bg-success";
        } else {
          let pct = 20;
          if (res.head_pose && Math.abs(res.head_pose.yaw) > 2) {
            pct = Math.min(95, Math.max(20, Math.round((Math.abs(res.head_pose.yaw) / 15.0) * 100)));
          } else if (res.blendshapes && res.blendshapes.blink_score > 0.1) {
            pct = Math.min(95, Math.max(20, Math.round((res.blendshapes.blink_score / 0.38) * 100)));
          }
          this.actionProgress.style.width = `${pct}%`;
          this.actionProgress.className = "progress-bar progress-bar-striped progress-bar-animated bg-info";
        }

        // If current step transitioned to next challenge
        if (res.step_completed) {
          if (res.all_completed) {
            // Liveness challenges completed! Move to final biometric face match!
            clearInterval(this.scanInterval);
            clearInterval(this.timerInterval);
            this.updateStatusBadge("Verifying Face Match...", "badge-neon-cyan");
            this.telemetryStatus.innerText = "MODE: BIOMETRIC_MATCHING";
            await this.finalizeAuthentication();
            return;
          } else {
            this.updateChallengeUI(res.current_step);
          }
        }
      } else {
        this.guideOval.className = "hud-guide-oval";
        this.actionFeedbackText.innerText = "Center your face inside the oval...";
      }

    } catch (err) {
      console.error("Frame processing error:", err);
    } finally {
      this.isProcessing = false;
    }
  }

  renderHUD(data) {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    if (data.head_pose) {
      this.telemetryPose.innerText = `POSE: Y: ${data.head_pose.yaw}° | P: ${data.head_pose.pitch}°`;
    }
    if (data.spoof_score !== undefined) {
      this.telemetrySpoof.innerText = `SPOOF_IDX: ${data.spoof_score.toFixed(2)}`;
    }

    if (data.has_face && data.bbox) {
      const b = data.bbox;
      this.ctx.strokeStyle = "#00f0ff";
      this.ctx.lineWidth = 2.5;
      this.ctx.strokeRect(b.x, b.y, b.w, b.h);

      // HUD corner accents
      const len = 15;
      this.ctx.strokeStyle = "#10b981";
      this.ctx.lineWidth = 4;
      // Top-left
      this.ctx.beginPath();
      this.ctx.moveTo(b.x, b.y + len);
      this.ctx.lineTo(b.x, b.y);
      this.ctx.lineTo(b.x + len, b.y);
      this.ctx.stroke();

      // Top-right
      this.ctx.beginPath();
      this.ctx.moveTo(b.x + b.w - len, b.y);
      this.ctx.lineTo(b.x + b.w, b.y);
      this.ctx.lineTo(b.x + b.w, b.y + len);
      this.ctx.stroke();
    }
  }

  async finalizeAuthentication() {
    this.actionFeedbackText.innerText = "Challenges passed! Extracting facial biometric vector...";
    this.actionProgress.style.width = "100%";
    this.actionProgress.className = "progress-bar progress-bar-striped progress-bar-animated bg-success";

    const finalFrame = this.captureFrameBase64();
    if (!finalFrame) return;

    try {
      const resp = await fetch("/api/auth/finalize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          session_id: this.sessionId,
          image: finalFrame
        })
      });

      const res = await resp.json();
      this.displayFinalResult(res);

    } catch (err) {
      console.error("Finalize error:", err);
      alert("Authentication error: " + err.message);
    }
  }

  displayFinalResult(res) {
    this.stopCameraLoop();
    this.resultCard.style.display = "block";
    this.challengeBanner.style.display = "none";

    if (res.access_granted && res.user) {
      // Access Granted
      this.updateStatusBadge("Access Granted", "badge-neon-emerald");
      this.guideOval.className = "hud-guide-oval active";

      this.resultIconContainer.innerHTML = `
        <div class="d-inline-flex p-3 rounded-circle" style="background: rgba(16, 185, 129, 0.2); border: 2px solid #10b981;">
          <i class="bi bi-shield-check text-success" style="font-size: 3rem;"></i>
        </div>
      `;
      this.resultTitle.innerText = "ACCESS GRANTED";
      this.resultTitle.className = "fw-bold text-success mb-1";
      this.resultSubtitle.innerText = res.message || "Biometric authentication confirmed.";

      this.resultUserProfile.style.display = "block";
      this.resultSpoofAlert.style.display = "none";

      this.resultUserName.innerText = res.user.full_name;
      this.resultUserId.innerText = res.user.user_id;
      this.resultUserDept.innerText = `${res.user.department} • ${res.user.role}`;
      if (res.user.photo_path) {
        this.resultUserPhoto.src = res.user.photo_path;
      }

      // Render Biometrically Unlocked Employee Operations
      const tasksSection = document.getElementById("resultTasksSection");
      const tasksList = document.getElementById("resultTasksList");
      const countBadge = document.getElementById("tasksCountBadge");

      if (tasksSection && tasksList) {
        tasksSection.style.display = "block";
        const tasks = res.tasks || [];
        countBadge.innerText = `${tasks.length} Assigned`;

        if (tasks.length === 0) {
          tasksList.innerHTML = `<div class="text-muted small text-center py-2">No pending operations assigned today.</div>`;
        } else {
          tasksList.innerHTML = tasks.map(t => {
            let prioClass = "badge-neon-cyan";
            if (t.priority === "CRITICAL") prioClass = "badge-neon-rose";
            else if (t.priority === "HIGH") prioClass = "badge-neon-amber";

            const isDone = t.status === "COMPLETED";

            return `
              <div class="p-2 rounded bg-dark border border-secondary border-opacity-25 d-flex justify-content-between align-items-center gap-2" id="task-card-${t.task_id}">
                <div>
                  <div class="d-flex align-items-center gap-1 mb-1">
                    <span class="badge ${prioClass}" style="font-size: 0.65rem;">${t.priority}</span>
                    <span class="text-white fw-semibold small">${t.title}</span>
                  </div>
                  <div class="text-muted small" style="font-size: 0.7rem;">${t.description ? t.description : ''} &bull; Due: ${t.due_date || 'Today'}</div>
                </div>
                <div>
                  ${isDone ? 
                    `<span class="badge badge-neon-emerald" style="font-size: 0.7rem;"><i class="bi bi-check-circle-fill me-1"></i> Completed</span>` :
                    `<button class="btn btn-sm btn-outline-success py-0 px-2" style="font-size: 0.75rem;" onclick="window.authenticator.markTaskDone('${t.task_id}')">
                      <i class="bi bi-check2 me-1"></i> Done
                    </button>`
                  }
                </div>
              </div>
            `;
          }).join("");
        }
      }

      this.metricConfidence.innerText = `${res.confidence_score}%`;
      this.metricDistance.innerText = res.cosine_distance;
      this.metricSpoof.innerText = res.spoof_score !== undefined ? `${res.spoof_score}` : "0.05";
      this.metricLiveness.innerText = "PASSED";
      this.metricLiveness.className = "text-end fw-bold text-success";

    } else {
      // Access Denied / Unrecognized
      this.updateStatusBadge("Access Denied", "badge-neon-rose");
      this.guideOval.className = "hud-guide-oval alert";

      const tasksSection = document.getElementById("resultTasksSection");
      if (tasksSection) tasksSection.style.display = "none";

      this.resultIconContainer.innerHTML = `
        <div class="d-inline-flex p-3 rounded-circle" style="background: rgba(244, 63, 94, 0.2); border: 2px solid #f43f5e;">
          <i class="bi bi-shield-x text-danger" style="font-size: 3rem;"></i>
        </div>
      `;
      this.resultTitle.innerText = "ACCESS DENIED";
      this.resultTitle.className = "fw-bold text-danger mb-1";
      this.resultSubtitle.innerText = res.message || "Biometric signature does not match any registered identity.";

      this.resultUserProfile.style.display = "none";
      this.resultSpoofAlert.style.display = "none";

      this.metricConfidence.innerText = `${res.confidence_score || 0}%`;
      this.metricDistance.innerText = res.cosine_distance || "N/A";
      this.metricSpoof.innerText = "0.10";
      this.metricLiveness.innerText = "PASSED";
      this.metricLiveness.className = "text-end fw-bold text-success";
    }
  }

  handleSpoofAlert(res) {
    this.stopCameraLoop();
    this.updateStatusBadge("Spoof Attack Alert", "badge-neon-rose");
    this.guideOval.className = "hud-guide-oval alert";

    this.resultCard.style.display = "block";
    this.challengeBanner.style.display = "none";

    this.resultIconContainer.innerHTML = `
      <div class="d-inline-flex p-3 rounded-circle" style="background: rgba(244, 63, 94, 0.25); border: 2px solid #f43f5e; box-shadow: 0 0 25px rgba(244,63,94,0.5);">
        <i class="bi bi-exclamation-octagon-fill text-danger" style="font-size: 3.5rem;"></i>
      </div>
    `;
    this.resultTitle.innerText = "SPOOF ATTACK DETECTED";
    this.resultTitle.className = "fw-bold text-danger mb-1";
    this.resultSubtitle.innerText = "Biometric spoof attempt blocked and logged.";

    this.resultUserProfile.style.display = "none";
    this.resultSpoofAlert.style.display = "block";
    this.resultSpoofReason.innerText = res.message || "Digital screen replay or paper photo detected.";

    this.metricConfidence.innerText = "0%";
    this.metricDistance.innerText = "N/A";
    this.metricSpoof.innerText = `${res.spoof_score || 1.0}`;
    this.metricLiveness.innerText = "REJECTED";
    this.metricLiveness.className = "text-end fw-bold text-danger";
  }

  handleTimeout() {
    this.stopCameraLoop();
    this.updateStatusBadge("Verification Timed Out", "badge-neon-amber");
    this.guideOval.className = "hud-guide-oval alert";
    alert("Authentication timed out! You must complete the randomized challenge within 15 seconds.");
    this.resetUI();
  }

  stopCameraLoop() {
    clearInterval(this.scanInterval);
    clearInterval(this.timerInterval);
    this.scanInterval = null;
    this.timerInterval = null;
    this.timerContainer.style.display = "none";
    this.scannerLine.style.display = "none";
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }

  stopCamera() {
    this.stopCameraLoop();
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    this.video.srcObject = null;
    this.resetUI();
  }

  resetUI() {
    this.stopCameraLoop();
    this.sessionId = null;
    this.sessionData = null;
    this.isProcessing = false;

    this.placeholder.style.display = "block";
    this.scannerLine.style.display = "none";
    this.challengeBanner.style.display = "none";
    this.resultCard.style.display = "none";
    this.btnRestart.style.display = "none";
    this.btnStop.style.display = "none";
    this.guideOval.className = "hud-guide-oval";
    this.telemetryStatus.innerText = "MODE: IDLE";
    this.telemetryPose.style.display = "none";
    this.telemetrySpoof.style.display = "none";

    this.updateStatusBadge("System Ready", "badge-neon-cyan");
  }

  async markTaskDone(taskId) {
    try {
      const resp = await fetch(`/api/tasks/${taskId}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "COMPLETED" })
      });
      const data = await resp.json();
      if (data.success) {
        const card = document.getElementById(`task-card-${taskId}`);
        if (card) {
          card.querySelector("div:last-child").innerHTML = `<span class="badge badge-neon-emerald" style="font-size: 0.7rem;"><i class="bi bi-check-circle-fill me-1"></i> Completed</span>`;
        }
      }
    } catch (err) {
      console.error("Task update error:", err);
    }
  }

  updateStatusBadge(text, badgeClass) {
    this.systemStatusBadge.className = `badge ${badgeClass} py-2 px-3`;
    this.systemStatusBadge.innerHTML = `<i class="bi bi-circle-fill me-1 small"></i> ${text}`;
  }
}

// Instantiate once DOM loads
document.addEventListener("DOMContentLoaded", () => {
  window.authenticator = new BiometricAuthenticator();
});
