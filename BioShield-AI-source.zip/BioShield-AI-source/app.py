import os
import sys
import io
import csv
import time
from flask import Flask, render_template, request, jsonify, Response, send_file
from config import SECRET_KEY, DEBUG, HOST, PORT, FACE_RECOGNITION_THRESHOLD, SPOOF_CONSECUTIVE_FRAMES_REQUIRED
from database.db import init_db
from database.models import UserModel, SecurityLogModel, TaskModel
from core.anti_spoofing import AntiSpoofingEngine
from core.liveness_detector import LivenessDetector
from core.face_recognition import FaceRecognitionEngine
from core.challenge_engine import ChallengeSessionManager
from utils import decode_base64_image, save_profile_image, save_audit_snapshot

# Initialize database schema on startup
init_db()

app = Flask(__name__)
app.config['SECRET_KEY'] = SECRET_KEY

# Pre-warm MediaPipe FaceLandmarker
try:
    LivenessDetector.get_landmarker()
except Exception as e:
    print(f"[Warning] MediaPipe Landmarker pre-warm: {e}")

# ==========================================
# PAGE ROUTES
# ==========================================

@app.route("/")
def index():
    """Portal Home Page: Architecture overview & quick launch."""
    analytics = SecurityLogModel.get_analytics()
    return render_template("index.html", analytics=analytics)

@app.route("/authenticate")
def authenticate_page():
    """Biometric Authentication Terminal with webcam and live challenge."""
    return render_template("authenticate.html")

@app.route("/register")
def register_page():
    """User Biometric Registration Wizard."""
    return render_template("register.html")

@app.route("/dashboard")
def dashboard_page():
    """Admin Dashboard with security analytics, user list, charts, and employee tasks."""
    users = UserModel.get_all()
    tasks = TaskModel.get_all()
    analytics = SecurityLogModel.get_analytics()
    recent_logs = SecurityLogModel.get_recent(limit=10)
    return render_template("dashboard.html", users=users, tasks=tasks, analytics=analytics, recent_logs=recent_logs)

@app.route("/logs")
def logs_page():
    """Detailed Security Audit Logs page with filters and snapshot inspection."""
    return render_template("logs.html")

# ==========================================
# BIOMETRIC AUTHENTICATION API
# ==========================================

@app.route("/api/auth/start-challenge", methods=["POST"])
def start_challenge():
    """
    Initiates a new randomized challenge-response liveness session.
    Returns session ID, challenge steps, and timeout expiration.
    """
    req_data = request.get_json(silent=True) or {}
    challenge_count = req_data.get("challenge_count", 2)

    session = ChallengeSessionManager.create_session(count=challenge_count)
    return jsonify({
        "success": True,
        "session_id": session["session_id"],
        "expires_at": session["expires_at"],
        "current_step": session["current_step"],
        "total_steps": session["total_steps"],
        "challenges": [
            {
                "type": c["type"],
                "title": c["title"],
                "instruction": c["instruction"],
                "icon": c["icon"]
            }
            for c in session["challenges"]
        ]
    })

@app.route("/api/auth/verify-step", methods=["POST"])
def verify_step():
    """
    Processes a live frame from the user's webcam for the current challenge step.
    Checks anti-spoofing and verifies liveness action (blink, head turn, smile).
    """
    req_data = request.get_json(silent=True)
    if not req_data:
        return jsonify({"success": False, "error": "No payload provided"}), 400

    session_id = req_data.get("session_id")
    image_base64 = req_data.get("image")

    if not session_id or not image_base64:
        return jsonify({"success": False, "error": "Missing session_id or image data"}), 400

    session = ChallengeSessionManager.get_session(session_id)
    if not session:
        return jsonify({
            "success": False,
            "expired": True,
            "error": "Session expired or invalid. Please restart challenge."
        }), 400

    frame_bgr = decode_base64_image(image_base64)
    if frame_bgr is None:
        return jsonify({"success": False, "error": "Failed to decode frame"}), 400

    # 1. Liveness & Facial Landmark Detection
    analysis = LivenessDetector.analyze_frame(frame_bgr)
    if not analysis.get("has_face"):
        return jsonify({
            "success": True,
            "has_face": False,
            "message": "No face detected. Please face the camera directly.",
            "session_id": session_id,
            "current_step": session["current_step"],
            "total_steps": session["total_steps"]
        })

    face_crop = analysis.get("face_crop")

    # 2. Anti-Spoofing Check on the cropped face (with multi-frame temporal debouncing)
    is_real, spoof_score, spoof_metrics = AntiSpoofingEngine.evaluate(face_crop, mode="live_stream")
    if not is_real:
        session["consecutive_spoof_frames"] = session.get("consecutive_spoof_frames", 0) + 1
        # Require consecutive corroborated attack frames to prevent false alarms from transient motion blur
        if session["consecutive_spoof_frames"] >= SPOOF_CONSECUTIVE_FRAMES_REQUIRED:
            ChallengeSessionManager.mark_spoof(session_id, reason="; ".join(spoof_metrics.get("reasons", [])))
            
            # Save snapshot for cybersecurity audit
            snapshot_url = save_audit_snapshot(frame_bgr, "SPOOF_DETECTED", "ATTACKER")
            SecurityLogModel.log(
                user_id="UNKNOWN",
                user_name="Unidentified / Attacker",
                status="SPOOF_DETECTED",
                reason=f"Spoof Attack Detected: {'; '.join(spoof_metrics.get('reasons', []))}",
                confidence_score=0.0,
                liveness_score=round(1.0 - spoof_score, 2),
                spoof_score=round(spoof_score, 2),
                snapshot_path=snapshot_url,
                ip_address=request.remote_addr,
                challenge_details=session.get("challenges")
            )

            ChallengeSessionManager.invalidate(session_id)

            return jsonify({
                "success": False,
                "spoof_detected": True,
                "message": "Anti-Spoof Alert: Digital replay or photo spoofing detected!",
                "spoof_score": spoof_score,
                "metrics": spoof_metrics
            })
    else:
        session["consecutive_spoof_frames"] = 0

    # 3. Check Current Challenge Action
    current_idx = session["current_step"]
    current_challenge = session["challenges"][current_idx]
    action_type = current_challenge["type"]

    action_passed, action_score, action_msg = LivenessDetector.verify_action(action_type, analysis)

    step_completed = False
    all_completed = False
    message = action_msg

    if action_passed:
        step_completed, update_msg = ChallengeSessionManager.update_step_success(session_id)
        message = update_msg
        all_completed = session.get("completed", False)

    return jsonify({
        "success": True,
        "has_face": True,
        "action_verified": action_passed,
        "step_completed": step_completed,
        "all_completed": all_completed,
        "message": message,
        "current_step": session["current_step"],
        "total_steps": session["total_steps"],
        "bbox": analysis["bbox"],
        "head_pose": analysis["head_pose"],
        "blendshapes": analysis["blendshapes"],
        "spoof_score": spoof_score
    })

@app.route("/api/auth/finalize", methods=["POST"])
def finalize_authentication():
    """
    Final phase: Validates that all randomized challenges passed,
    computes face embedding, matches against registered users database,
    and returns Access Granted / Access Denied.
    """
    req_data = request.get_json(silent=True)
    if not req_data:
        return jsonify({"success": False, "error": "No payload provided"}), 400

    session_id = req_data.get("session_id")
    image_base64 = req_data.get("image")

    if not session_id or not image_base64:
        return jsonify({"success": False, "error": "Missing session_id or image"}), 400

    session = ChallengeSessionManager.get_session(session_id)
    if not session:
        return jsonify({"success": False, "error": "Session expired or invalid"}), 400

    if not session.get("completed", False):
        # Challenges were not completed
        SecurityLogModel.log(
            user_id="UNKNOWN",
            user_name="Unidentified",
            status="LIVENESS_FAILED",
            reason="Authentication aborted: Liveness challenge incomplete or timed out.",
            ip_address=request.remote_addr,
            challenge_details=session.get("challenges")
        )
        ChallengeSessionManager.invalidate(session_id)
        return jsonify({
            "success": False,
            "access_granted": False,
            "status": "LIVENESS_FAILED",
            "message": "Liveness challenges incomplete."
        }), 400

    frame_bgr = decode_base64_image(image_base64)
    if frame_bgr is None:
        return jsonify({"success": False, "error": "Failed to decode final frame"}), 400

    # 1. Final Anti-Spoofing check
    analysis = LivenessDetector.analyze_frame(frame_bgr)
    face_crop = analysis.get("face_crop") if analysis.get("has_face") else frame_bgr
    is_real, spoof_score, spoof_metrics = AntiSpoofingEngine.evaluate(face_crop)

    if not is_real:
        snapshot_url = save_audit_snapshot(frame_bgr, "SPOOF_DETECTED", "ATTACKER")
        SecurityLogModel.log(
            user_id="UNKNOWN",
            user_name="Unidentified Attacker",
            status="SPOOF_DETECTED",
            reason=f"Final Anti-Spoof Failed: {'; '.join(spoof_metrics.get('reasons', []))}",
            spoof_score=round(spoof_score, 2),
            snapshot_path=snapshot_url,
            ip_address=request.remote_addr
        )
        ChallengeSessionManager.invalidate(session_id)
        return jsonify({
            "success": False,
            "access_granted": False,
            "status": "SPOOF_DETECTED",
            "message": "Final anti-spoofing check failed."
        })

    # 2. Extract Facial Embedding
    query_embedding = FaceRecognitionEngine.extract_embedding(face_crop if face_crop is not None else frame_bgr)
    if query_embedding is None:
        snapshot_url = save_audit_snapshot(frame_bgr, "DENIED", "NO_FACE")
        SecurityLogModel.log(
            user_id="UNKNOWN",
            user_name="Unidentified",
            status="DENIED",
            reason="Failed to extract facial biometric features from frame.",
            snapshot_path=snapshot_url,
            ip_address=request.remote_addr
        )
        ChallengeSessionManager.invalidate(session_id)
        return jsonify({
            "success": False,
            "access_granted": False,
            "status": "DENIED",
            "message": "Unable to extract clear facial biometric features. Please ensure good lighting."
        })

    # 3. Match against Registered Users
    active_users = UserModel.get_all_active_embeddings()
    matched, user, distance, confidence = FaceRecognitionEngine.match_identity(
        query_embedding, active_users, threshold=FACE_RECOGNITION_THRESHOLD
    )

    # Invalidate challenge session
    ChallengeSessionManager.invalidate(session_id)

    if matched and user:
        # Access Granted!
        snapshot_url = save_audit_snapshot(frame_bgr, "GRANTED", user["user_id"])
        SecurityLogModel.log(
            user_id=user["user_id"],
            user_name=user["full_name"],
            status="GRANTED",
            reason=f"Biometric Match Confirmed (Cosine Dist: {distance:.3f})",
            confidence_score=confidence,
            liveness_score=1.0,
            spoof_score=round(spoof_score, 2),
            snapshot_path=snapshot_url,
            ip_address=request.remote_addr,
            challenge_details=session.get("audit_trail")
        )

        # Fetch operational tasks assigned to this employee
        user_tasks = TaskModel.get_by_user_id(user["user_id"])

        return jsonify({
            "success": True,
            "access_granted": True,
            "status": "GRANTED",
            "user": {
                "user_id": user["user_id"],
                "full_name": user["full_name"],
                "department": user["department"],
                "role": user["role"],
                "photo_path": user["photo_path"]
            },
            "tasks": user_tasks,
            "confidence_score": confidence,
            "cosine_distance": distance,
            "snapshot_url": snapshot_url,
            "message": f"Welcome, {user['full_name']}! Identity verified."
        })
    else:
        # Access Denied: Unrecognized User
        snapshot_url = save_audit_snapshot(frame_bgr, "DENIED", "UNRECOGNIZED")
        SecurityLogModel.log(
            user_id="UNKNOWN",
            user_name="Unrecognized Person",
            status="DENIED",
            reason=f"Unrecognized Face (Best Dist: {distance:.3f} > {FACE_RECOGNITION_THRESHOLD})",
            confidence_score=confidence,
            liveness_score=1.0,
            spoof_score=round(spoof_score, 2),
            snapshot_path=snapshot_url,
            ip_address=request.remote_addr
        )

        return jsonify({
            "success": True,
            "access_granted": False,
            "status": "DENIED",
            "confidence_score": confidence,
            "cosine_distance": distance,
            "message": "Access Denied: Face not registered in the BioShield system."
        })

# ==========================================
# USER MANAGEMENT APIS
# ==========================================

@app.route("/api/users/register", methods=["POST"])
def register_user():
    """
    Registers a new biometric user profile.
    Performs anti-spoofing check, extracts 512-D embedding, and stores profile.
    """
    req_data = request.get_json(silent=True)
    if not req_data:
        return jsonify({"success": False, "error": "No data received"}), 400

    user_id = req_data.get("user_id", "").strip().upper()
    full_name = req_data.get("full_name", "").strip()
    email = req_data.get("email", "").strip().lower()
    department = req_data.get("department", "Engineering").strip()
    role = req_data.get("role", "User").strip()
    image_base64 = req_data.get("image")

    if not user_id or not full_name or not email or not image_base64:
        return jsonify({"success": False, "error": "Please provide User ID, Full Name, Email, and a clear Face Capture."}), 400

    # Check for existing user
    existing = UserModel.get_by_user_id(user_id)
    if existing:
        return jsonify({"success": False, "error": f"User ID '{user_id}' already registered."}), 400

    frame_bgr = decode_base64_image(image_base64)
    if frame_bgr is None:
        return jsonify({"success": False, "error": "Invalid face image."}), 400

    # Liveness & face check on registration image
    analysis = LivenessDetector.analyze_frame(frame_bgr)
    if not analysis.get("has_face"):
        return jsonify({"success": False, "error": "No clear face detected in the registration frame."}), 400

    face_crop = analysis.get("face_crop", frame_bgr)

    # Anti-spoofing on registration frame (using registration calibrated mode)
    is_real, spoof_score, spoof_metrics = AntiSpoofingEngine.evaluate(face_crop, mode="registration")
    if not is_real:
        reasons_text = "; ".join(spoof_metrics.get("reasons", [])) or "Presentation attack detected"
        return jsonify({
            "success": False,
            "error": f"Registration Rejected: Anti-spoofing system detected: {reasons_text}. Please ensure clear facial lighting and look directly at the camera.",
            "metrics": spoof_metrics
        }), 400

    # Extract facial embedding
    embedding = FaceRecognitionEngine.extract_embedding(face_crop)
    if embedding is None:
        return jsonify({"success": False, "error": "Could not generate biometric signature from photo."}), 400

    # Save photo and store record
    photo_path = save_profile_image(face_crop, user_id)
    created_id = UserModel.create(user_id, full_name, email, department, role, photo_path, embedding)

    if not created_id:
        return jsonify({"success": False, "error": "Failed to create user record. Email might already exist."}), 400

    # Audit log
    SecurityLogModel.log(
        user_id=user_id,
        user_name=full_name,
        status="USER_REGISTERED",
        reason=f"New user registered: {full_name} ({user_id})",
        confidence_score=100.0,
        liveness_score=1.0,
        spoof_score=round(spoof_score, 2),
        snapshot_path=photo_path,
        ip_address=request.remote_addr
    )

    return jsonify({
        "success": True,
        "message": f"Biometric profile for '{full_name}' successfully enrolled!",
        "user_id": user_id,
        "photo_path": photo_path
    })

@app.route("/api/users", methods=["GET"])
def list_users():
    """Returns list of registered biometric users."""
    users = UserModel.get_all()
    return jsonify({"success": True, "users": users})

@app.route("/api/users/<user_id>/toggle", methods=["POST"])
def toggle_user(user_id):
    """Enables or disables biometric access for a user."""
    updated = UserModel.toggle_status(user_id)
    return jsonify({"success": updated})

@app.route("/api/users/<user_id>", methods=["DELETE"])
def delete_user(user_id):
    """Removes a user and their biometric embedding from the database."""
    deleted = UserModel.delete(user_id)
    return jsonify({"success": deleted})

# ==========================================
# EMPLOYEE TASK DISPATCH APIS (UNIQUE INNOVATION)
# ==========================================

@app.route("/api/tasks", methods=["GET"])
def get_tasks():
    """Retrieves operational tasks assigned to an employee or all tasks for admin."""
    user_id = request.args.get("user_id")
    status = request.args.get("status")
    if user_id:
        tasks = TaskModel.get_by_user_id(user_id, status=status)
    else:
        tasks = TaskModel.get_all()
    return jsonify({"success": True, "tasks": tasks})

@app.route("/api/tasks", methods=["POST"])
def create_task():
    """Assigns a new operational task to a specific employee."""
    data = request.get_json(silent=True) or {}
    user_id = data.get("user_id", "").strip().upper()
    title = data.get("title", "").strip()
    description = data.get("description", "").strip()
    priority = data.get("priority", "MEDIUM").strip().upper()
    due_date = data.get("due_date", "Today").strip()

    if not user_id or not title:
        return jsonify({"success": False, "error": "User ID and Task Title are required."}), 400

    # Verify user exists
    user = UserModel.get_by_user_id(user_id)
    if not user:
        return jsonify({"success": False, "error": f"No registered user found with ID '{user_id}'."}), 400

    import uuid
    task_id = f"TSK-{uuid.uuid4().hex[:6].upper()}"
    new_id = TaskModel.create(task_id, user_id, title, description, priority, due_date)

    if not new_id:
        return jsonify({"success": False, "error": "Failed to create task."}), 500

    return jsonify({
        "success": True,
        "message": f"Task '{title}' assigned to {user['full_name']} ({user_id})!",
        "task_id": task_id
    })

@app.route("/api/tasks/<task_id>/status", methods=["POST"])
def update_task_status(task_id):
    """Updates status of an employee task (PENDING, IN_PROGRESS, COMPLETED)."""
    data = request.get_json(silent=True) or {}
    new_status = data.get("status", "COMPLETED").strip().upper()
    updated = TaskModel.update_status(task_id, new_status)
    return jsonify({"success": updated, "status": new_status})

@app.route("/api/tasks/<task_id>", methods=["DELETE"])
def delete_task(task_id):
    """Deletes an operational task."""
    deleted = TaskModel.delete(task_id)
    return jsonify({"success": deleted})

# ==========================================
# AUDIT LOGS & ANALYTICS APIS
# ==========================================

@app.route("/api/logs", methods=["GET"])
def get_logs():
    """Returns recent security logs with optional filtering."""
    status = request.args.get("status", "ALL")
    search = request.args.get("search", "").strip()
    limit = int(request.args.get("limit", 50))
    logs = SecurityLogModel.get_recent(limit=limit, status_filter=status, search=search)
    return jsonify({"success": True, "logs": logs})

@app.route("/api/logs/export", methods=["GET"])
def export_logs_csv():
    """Exports security audit ledger into downloadable CSV format."""
    logs = SecurityLogModel.get_recent(limit=500)
    
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "Log ID", "Timestamp", "User ID", "User Name", "Status",
        "Reason", "Confidence (%)", "Liveness Score", "Spoof Score", "IP Address"
    ])

    for row in logs:
        writer.writerow([
            row["id"], row["timestamp"], row["user_id"] or "N/A", row["user_name"] or "N/A",
            row["status"], row["reason"] or "", row["confidence_score"],
            row["liveness_score"], row["spoof_score"], row["ip_address"]
        ])

    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=BioShield_Security_Logs.csv"}
    )

@app.route("/api/analytics", methods=["GET"])
def get_analytics():
    """Returns dashboard statistics and charts data."""
    analytics = SecurityLogModel.get_analytics()
    return jsonify({"success": True, "analytics": analytics})

@app.route("/api/test/anti-spoof", methods=["POST"])
def test_anti_spoof():
    """
    Diagnostic tool endpoint: Evaluates an uploaded image for presentation attacks.
    Returns Laplacian variance, FFT moiré ratio, color diversity, and glare index.
    """
    req_data = request.get_json(silent=True) or {}
    image_base64 = req_data.get("image")
    if not image_base64:
        return jsonify({"success": False, "error": "No image provided"}), 400

    frame_bgr = decode_base64_image(image_base64)
    if frame_bgr is None:
        return jsonify({"success": False, "error": "Invalid image"}), 400

    analysis = LivenessDetector.analyze_frame(frame_bgr)
    face_crop = analysis.get("face_crop", frame_bgr) if analysis.get("has_face") else frame_bgr

    is_real, spoof_score, metrics = AntiSpoofingEngine.evaluate(face_crop)
    return jsonify({
        "success": True,
        "is_real": is_real,
        "spoof_score": spoof_score,
        "metrics": metrics,
        "has_face": analysis.get("has_face", False)
    })

# ==========================================
# SERVER STARTUP
# ==========================================

if __name__ == "__main__":
    print(f"\n========================================================")
    print(f"  BioShield AI – Intelligent Biometric Authentication  ")
    print(f"  Server Running on http://{HOST}:{PORT}             ")
    print(f"========================================================\n")
    app.run(host=HOST, port=PORT, debug=DEBUG)
