import os
import sys
import json
import cv2
import numpy as np

# Ensure project root in sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from app import app
from utils import encode_image_to_base64

def run_tests():
    print("\n--- Running BioShield AI Automated Test Suite ---")
    client = app.test_client()

    # 1. Page Routes Test
    routes = ["/", "/authenticate", "/register", "/dashboard", "/logs"]
    for r in routes:
        resp = client.get(r)
        assert resp.status_code == 200, f"Route {r} returned {resp.status_code}"
        print(f"[PASS] GET {r} -> HTTP 200")

    # 2. Challenge Start API
    resp = client.post("/api/auth/start-challenge", json={"challenge_count": 2})
    assert resp.status_code == 200, "Failed to start challenge"
    data = json.loads(resp.data)
    assert data["success"] is True
    session_id = data["session_id"]
    challenges = data["challenges"]
    assert len(challenges) == 2
    print(f"[PASS] POST /api/auth/start-challenge -> Session {session_id[:8]}... created with {len(challenges)} challenges")

    # 3. Create dummy test frame for verify-step
    test_img = np.full((300, 300, 3), 100, dtype=np.uint8)
    img_b64 = "data:image/jpeg;base64," + encode_image_to_base64(test_img)

    # 4. Verify Step API
    resp = client.post("/api/auth/verify-step", json={
        "session_id": session_id,
        "image": img_b64
    })
    assert resp.status_code == 200
    step_data = json.loads(resp.data)
    print(f"[PASS] POST /api/auth/verify-step -> Response received (has_face: {step_data.get('has_face')})")

    # 5. List Users API
    resp = client.get("/api/users")
    assert resp.status_code == 200
    users_data = json.loads(resp.data)
    assert users_data["success"] is True
    print(f"[PASS] GET /api/users -> Found {len(users_data['users'])} registered users")

    # 6. Analytics API
    resp = client.get("/api/analytics")
    assert resp.status_code == 200
    analytics_data = json.loads(resp.data)
    assert analytics_data["success"] is True
    print(f"[PASS] GET /api/analytics -> Total Users: {analytics_data['analytics']['total_users']}, Attempts: {analytics_data['analytics']['total_attempts']}")

    # 7. Audit Logs API & Export
    resp = client.get("/api/logs?status=ALL")
    assert resp.status_code == 200
    logs_data = json.loads(resp.data)
    assert logs_data["success"] is True
    print(f"[PASS] GET /api/logs -> Retrieved {len(logs_data['logs'])} audit log entries")

    resp = client.get("/api/logs/export")
    assert resp.status_code == 200
    assert "text/csv" in resp.content_type
    print(f"[PASS] GET /api/logs/export -> Generated CSV ({len(resp.data)} bytes)")

    # 8. Anti-Spoof Diagnostic API
    resp = client.post("/api/test/anti-spoof", json={"image": img_b64})
    assert resp.status_code == 200
    spoof_res = json.loads(resp.data)
    assert spoof_res["success"] is True
    print(f"[PASS] POST /api/test/anti-spoof -> Evaluated (is_real: {spoof_res['is_real']}, score: {spoof_res['spoof_score']})")

    # 9. Employee Operational Task APIs (Biometric Dispatch)
    resp = client.get("/api/tasks?user_id=BIO-1001")
    assert resp.status_code == 200
    tasks_data = json.loads(resp.data)
    assert tasks_data["success"] is True
    print(f"[PASS] GET /api/tasks?user_id=BIO-1001 -> Retrieved {len(tasks_data['tasks'])} employee operations")

    resp = client.post("/api/tasks", json={
        "user_id": "BIO-1001",
        "title": "Verify Perimeter Sensor Calibration",
        "description": "Test infrared sensor trigger points",
        "priority": "HIGH",
        "due_date": "Today"
    })
    assert resp.status_code == 200
    new_task = json.loads(resp.data)
    assert new_task["success"] is True
    created_tid = new_task["task_id"]
    print(f"[PASS] POST /api/tasks -> Created task {created_tid}")

    resp = client.post(f"/api/tasks/{created_tid}/status", json={"status": "COMPLETED"})
    assert resp.status_code == 200
    print(f"[PASS] POST /api/tasks/{created_tid}/status -> Marked COMPLETED")

    resp = client.delete(f"/api/tasks/{created_tid}")
    assert resp.status_code == 200
    print(f"[PASS] DELETE /api/tasks/{created_tid} -> Deleted task")

    print("\n--- ALL TESTS PASSED SUCCESSFULLY! ---\n")

if __name__ == "__main__":
    run_tests()
