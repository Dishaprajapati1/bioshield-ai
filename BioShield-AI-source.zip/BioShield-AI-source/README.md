# 🛡️ BioShield AI – Intelligent Biometric Authentication System
> **BTech Major Project | AI/ML + Computer Vision + Cybersecurity**

BioShield AI is a state-of-the-art AI-powered facial authentication application that integrates deep learning facial recognition, real-time 3D landmark liveness challenges, and multi-spectral anti-spoofing algorithms to verify authorized users while rigorously preventing presentation attacks (such as static 2D paper printouts, screen replays, and video loops).


> **Prototype security note:** The Flask source is an educational prototype, not an internet-ready biometric service. Its dashboard and management APIs do not have authentication. Do not deploy it publicly or use real biometric or personal data until access control, storage, retention, and production security have been implemented and reviewed. The public GitHub Pages link is a separate read-only static preview with synthetic data only.

---

## 🌟 Key Features

1. **User Registration & Enrollment**: Enrolls users with metadata (ID, Name, Email, Department, Role) and converts live webcam facial captures into 512-dimensional L2-normalized vector embeddings using DeepFace (`Facenet512`).
2. **Face Recognition**: Identifies registered users in real-time through high-accuracy Cosine Similarity matching against stored SQLite biometric embeddings.
3. **Real-Time Liveness Detection**: Leverages Google MediaPipe 468-point 3D FaceLandmarker to detect eye blinks (Eye Aspect Ratio & blendshapes), head poses (Yaw, Pitch, Roll Euler angles), and smiles.
4. **Multi-Spectral Anti-Spoofing Engine**:
   - **Laplacian Variance**: Analyzes micro-texture and sharpness to filter out low-resolution prints or out-of-focus paper attacks.
   - **2D Fast Fourier Transform (FFT)**: Detects periodic high-frequency grid frequencies (moiré artifacts) characteristic of smartphone, tablet, and laptop LCD/OLED screens.
   - **Chrominance & Specular Glare Analysis**: Examines YCrCb/HSV skin distribution and glass reflection hotspots.
5. **Dynamic Challenge-Response**: Server generates randomized, timed action sequences (e.g., *Step 1: Turn Head Left*, *Step 2: Blink Eyes*) with a strict 18-second countdown. Static photos and pre-recorded videos cannot predict or satisfy the random challenge.
6. **Unique Innovation – Zero-Trust Biometric Task Dispatch**:
   - Most biometric projects stop at a simple "Access Granted" message.
   - **BioShield AI** implements a **Biometrically-Gated Task Authorization Terminal**: When an employee successfully passes facial authentication, the system dynamically unlocks and presents **confidential operational tasks and directives assigned specifically to that employee**.
   - Employees can review priority-coded tasks (`CRITICAL`, `HIGH`, `MEDIUM`) and mark operations completed directly from the terminal.
7. **Executive Admin Dashboard**: Visual analytics powered by Chart.js (Authentication outcomes, hourly activity, user management, status toggles, deletion, and full task allocation).
8. **Presentation Attack Diagnostic Sandbox**: Interactive tool directly in the dashboard to test and inspect any photo/screen against the mathematical anti-spoofing algorithms.
9. **Forensic Security Audit Ledger**: Logs every authentication attempt with timestamp, client IP, outcome badge, confidence score, spoof score, and facial snapshot capture. Supports CSV export for compliance reporting.

---

## 🛠️ Technology Stack

| Layer | Technologies |
|---|---|
| **Programming Language** | Python 3.14 |
| **Facial Landmark & Liveness** | Google MediaPipe Tasks API (`face_landmarker.task`) |
| **Biometric Face Recognition** | DeepFace (`Facenet512` 512-D Embedding Model) |
| **Computer Vision & Anti-Spoofing** | OpenCV (`cv2`), NumPy, SciPy (2D-FFT, Laplacian, YCrCb) |
| **Backend Web Framework** | Flask (REST API Architecture) |
| **Database** | SQLite (Thread-safe, indexed schema) |
| **Frontend UI / UX** | HTML5 Canvas, Vanilla JavaScript (ES6+), Bootstrap 5, Chart.js |

---

## 📐 System Architecture & Workflow

```
[Webcam Stream]
      │
      ▼
[MediaPipe 3D Landmark & Head Pose Engine]
      │
      ├──> Face Detected? ──(No)──> Prompt User to Center Face
      │
      ▼ (Yes)
[Anti-Spoofing Defense Engine]
      ├── 1. Laplacian Edge Variance Analysis (Blur & Texture)
      ├── 2. 2D Fast Fourier Transform (Screen Moiré Detection)
      ├── 3. YCrCb Skin Chrominance & Specular Glare Detection
      │
      ├──> Spoof Detected? ──(Yes)──> 🚨 DENY & LOG SPOOF ATTACK
      │
      ▼ (Passed)
[Randomized Challenge-Response Engine]
      ├── Step 1: Head Turn (Yaw < -18° or > +18°)
      ├── Step 2: Natural Eye Blink (Blendshape > 0.45)
      ├── 15-Second Expiring Session Token
      │
      ├──> Challenge Incomplete / Timeout? ──> ⚠️ DENY & LOG LIVENESS FAILED
      │
      ▼ (All Steps Passed)
[DeepFace Facenet512 Feature Extraction]
      ├── Generate 512-D L2-Normalized Vector
      ├── Compute Cosine Distance: d = 1 - (A . B)
      │
      ├──> d <= 0.380?
            ├── (Yes) ──>  ACCESS GRANTED (Welcome User, Log Snapshot)
            └── (No)  ──> ❌ ACCESS DENIED (Unrecognized Identity)
```

---

## 🚀 Quick Start Guide

### 1. Set Workspace
Recommended workspace path:
```powershell
cd C:\Users\praja\.gemini\antigravity\scratch\bioshield_ai
```

### 2. Verify / Install Dependencies
Dependencies are already configured and installed. If setting up on a new machine:
```bash
pip install -r requirements.txt
```

### 3. Launch Application
Run the startup script:
```bash
python run.py
```
Open your browser and navigate to:
👉 **`http://127.0.0.1:5000`**

---

## 🌐 Application Endpoints

- **`/`**: Portal overview & architectural specifications.
- **`/authenticate`**: Live Biometric Kiosk with webcam HUD, real-time bounding box, and randomized challenges.
- **`/register`**: Biometric user enrollment wizard with live anti-spoof checks.
- **`/dashboard`**: Admin analytics dashboard with Chart.js charts and user management.
- **`/logs`**: Forensic security audit ledger with snapshot inspection modal and CSV export.

---

## 🧪 Automated Testing

Run the included automated test suite:
```bash
python test_app.py
```
This tests all page routes, challenge APIs, step verifications, anti-spoofing diagnostics, user queries, and CSV exports.

---

## 🎓 Academic Viva & Technical Defense FAQ

### Q1: How does BioShield AI prevent digital screen replay attacks?
**Answer:** BioShield AI uses a dual defense mechanism:
1. **Mathematical Anti-Spoofing**: Digital screens (LCD/OLED) display images via fixed pixel matrix grids and refresh frequencies. When captured by a webcam, this generates high-frequency interference called **moiré patterns**. BioShield AI transforms the facial image into the frequency domain via **2D Fast Fourier Transform (FFT)** and detects abnormal high-frequency spectral energy ratios.
2. **Dynamic Challenge-Response**: Pre-recorded videos cannot predict the randomized sequence of liveness challenges generated by the server per session.

### Q2: What is the purpose of the 512-dimensional vector embedding?
**Answer:** Instead of storing raw photos (which poses cybersecurity and privacy risks), DeepFace (`Facenet512`) projects the user's facial geometry into a compact, normalized 512-dimensional hypersphere where Euclidean and Cosine distances directly reflect identity similarity:
$$\text{Distance} = 1 - \frac{\mathbf{u} \cdot \mathbf{v}}{\|\mathbf{u}\|_2 \|\mathbf{v}\|_2}$$

### Q3: How is Eye Aspect Ratio (EAR) or blink detection measured?
**Answer:** MediaPipe outputs 468 3D landmarks and 52 blendshape coefficients. BioShield AI monitors `eyeBlinkLeft` and `eyeBlinkRight` probabilities ($> 0.45$) along with landmark displacement, verifying both closure and reopening to prevent static photo cutouts.

---

## 📜 License & Credits
Developed as a **BTech Major Project** in **AI/ML & Cybersecurity**.
Created with OpenCV, Google MediaPipe, DeepFace, and Flask.
