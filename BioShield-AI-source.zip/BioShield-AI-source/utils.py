import base64
import os
import time
import uuid
import cv2
import numpy as np
from config import UPLOAD_PROFILES_DIR, UPLOAD_LOGS_DIR

def decode_base64_image(base64_string):
    """
    Decodes a base64 encoded image string (e.g., from an HTML5 Canvas data URL)
    into an OpenCV BGR numpy array.
    """
    if not base64_string:
        return None

    try:
        if "," in base64_string:
            # Strip data:image/jpeg;base64, prefix
            base64_string = base64_string.split(",")[1]

        image_data = base64.b64decode(base64_string)
        nparr = np.frombuffer(image_data, np.uint8)
        img_bgr = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        return img_bgr
    except Exception as e:
        print(f"[Utils] Error decoding base64 image: {e}")
        return None

def encode_image_to_base64(img_bgr, format=".jpg"):
    """
    Encodes an OpenCV BGR image into a base64 string.
    """
    if img_bgr is None:
        return ""
    try:
        success, buffer = cv2.imencode(format, img_bgr)
        if not success:
            return ""
        return base64.b64encode(buffer).decode("utf-8")
    except Exception as e:
        print(f"[Utils] Error encoding image to base64: {e}")
        return ""

def save_profile_image(img_bgr, user_id):
    """
    Saves a registered user's profile portrait and returns the relative URL path.
    """
    filename = f"user_{user_id}_{int(time.time())}.jpg"
    filepath = os.path.join(UPLOAD_PROFILES_DIR, filename)
    cv2.imwrite(filepath, img_bgr)
    return f"/static/uploads/profiles/{filename}"

def save_audit_snapshot(img_bgr, status, user_id="UNKNOWN"):
    """
    Saves an authentication attempt snapshot for the security audit ledger.
    """
    if img_bgr is None:
        return None
    filename = f"audit_{status.lower()}_{user_id}_{uuid.uuid4().hex[:8]}_{int(time.time())}.jpg"
    filepath = os.path.join(UPLOAD_LOGS_DIR, filename)
    cv2.imwrite(filepath, img_bgr)
    return f"/static/uploads/logs/{filename}"
