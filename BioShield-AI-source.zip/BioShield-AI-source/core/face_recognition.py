import os
import cv2
import numpy as np
from deepface import DeepFace
from config import DEEPFACE_MODEL_NAME, FACE_RECOGNITION_THRESHOLD

class FaceRecognitionEngine:
    """
    BioShield AI Facial Recognition Engine.
    Uses DeepFace Facenet512 for high-dimensional biometric representation and cosine similarity matching.
    """

    @staticmethod
    def extract_embedding(image_input):
        """
        Extracts a 512-dimensional facial embedding vector.
        image_input can be:
            - BGR numpy array
            - File path string
        Returns:
            np.ndarray of shape (512,) normalized to unit length, or None if extraction fails.
        """
        if image_input is None:
            return None

        try:
            # DeepFace expects RGB format or file path
            if isinstance(image_input, np.ndarray):
                if len(image_input.shape) == 2:
                    image_input = cv2.cvtColor(image_input, cv2.COLOR_GRAY2RGB)
                elif image_input.shape[2] == 3:
                    # Convert OpenCV BGR to RGB
                    image_input = cv2.cvtColor(image_input, cv2.COLOR_BGR2RGB)

            representations = DeepFace.represent(
                img_path=image_input,
                model_name=DEEPFACE_MODEL_NAME,
                enforce_detection=False,
                align=True
            )

            if not representations or len(representations) == 0:
                return None

            raw_emb = np.array(representations[0]["embedding"], dtype=np.float32)
            # L2 normalization for robust cosine comparison
            norm = np.linalg.norm(raw_emb)
            if norm > 0:
                raw_emb = raw_emb / norm
            return raw_emb

        except Exception as e:
            print(f"[FaceRecognitionEngine] Error during embedding extraction: {e}")
            return None

    @staticmethod
    def compute_cosine_distance(emb1, emb2):
        """
        Computes cosine distance between two L2-normalized embedding vectors.
        Distance = 1.0 - (emb1 . emb2)
        0.0 = identical face, 1.0+ = completely dissimilar
        """
        if emb1 is None or emb2 is None:
            return 1.0
        dot_product = np.dot(emb1, emb2)
        distance = 1.0 - float(dot_product)
        return max(0.0, min(2.0, distance))

    @classmethod
    def match_identity(cls, query_embedding, registered_users, threshold=FACE_RECOGNITION_THRESHOLD):
        """
        Compares query_embedding against all registered active users.
        Returns:
            match_found (bool): True if distance <= threshold
            best_user (dict or None): Matched user details
            min_distance (float): Lowest distance recorded
            confidence_pct (float): 0% to 100% confidence rating
        """
        if query_embedding is None or not registered_users:
            return False, None, 1.0, 0.0

        best_user = None
        min_distance = 2.0

        for user in registered_users:
            candidate_emb = user.get("embedding")
            if candidate_emb is None:
                continue

            dist = cls.compute_cosine_distance(query_embedding, candidate_emb)
            if dist < min_distance:
                min_distance = dist
                best_user = user

        match_found = (best_user is not None) and (min_distance <= threshold)

        # Calculate confidence score as a percentage
        # If dist == 0, confidence = 100%. If dist == threshold, confidence = 50%.
        if min_distance <= threshold:
            confidence_pct = round((1.0 - (min_distance / (threshold * 1.5))) * 100.0, 1)
        else:
            confidence_pct = max(0.0, round((1.0 - (min_distance / 1.0)) * 50.0, 1))

        confidence_pct = max(0.0, min(99.9, confidence_pct))

        return match_found, best_user, round(min_distance, 4), confidence_pct
