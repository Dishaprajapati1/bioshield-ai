import time
import uuid
import random
from config import CHALLENGE_TIMEOUT_SECONDS, DEFAULT_CHALLENGE_COUNT

AVAILABLE_CHALLENGES = [
    {
        "type": "turn_left",
        "title": "Turn Head Left",
        "instruction": "Please turn your head towards your LEFT",
        "icon": "bi-arrow-left-circle",
        "min_frames_hold": 2
    },
    {
        "type": "turn_right",
        "title": "Turn Head Right",
        "instruction": "Please turn your head towards your RIGHT",
        "icon": "bi-arrow-right-circle",
        "min_frames_hold": 2
    },
    {
        "type": "blink",
        "title": "Blink Eyes",
        "instruction": "Blink your eyes naturally",
        "icon": "bi-eye",
        "min_frames_hold": 1
    },
    {
        "type": "smile",
        "title": "Smile",
        "instruction": "Smile comfortably at the camera",
        "icon": "bi-emoji-smile",
        "min_frames_hold": 2
    }
]

class ChallengeSessionManager:
    """
    BioShield AI Randomized Challenge-Response Session Orchestrator.
    Manages cryptographic challenge-response lifecycles to prevent video replay and photo attacks.
    """
    _sessions = {}

    @classmethod
    def create_session(cls, count=DEFAULT_CHALLENGE_COUNT):
        """Generates a new randomized challenge verification session."""
        cls.cleanup_expired()

        session_id = str(uuid.uuid4())
        # Pick 'count' unique challenges randomly
        selected_challenges = random.sample(AVAILABLE_CHALLENGES, min(count, len(AVAILABLE_CHALLENGES)))

        session_data = {
            "session_id": session_id,
            "created_at": time.time(),
            "expires_at": time.time() + CHALLENGE_TIMEOUT_SECONDS,
            "challenges": selected_challenges,
            "current_step": 0,
            "total_steps": len(selected_challenges),
            "step_success_frames": 0,
            "completed": False,
            "spoof_detected": False,
            "audit_trail": []
        }

        cls._sessions[session_id] = session_data
        return session_data

    @classmethod
    def get_session(cls, session_id):
        """Retrieves an active session if not expired."""
        cls.cleanup_expired()
        session = cls._sessions.get(session_id)
        if not session:
            return None
        if time.time() > session["expires_at"]:
            del cls._sessions[session_id]
            return None
        return session

    @classmethod
    def update_step_success(cls, session_id):
        """Advances to the next challenge step when threshold hold frames are met."""
        session = cls.get_session(session_id)
        if not session:
            return False, "Session expired or invalid"

        current_idx = session["current_step"]
        current_challenge = session["challenges"][current_idx]
        min_hold = current_challenge.get("min_frames_hold", 1)

        session["step_success_frames"] += 1

        if session["step_success_frames"] >= min_hold:
            # Step passed!
            session["audit_trail"].append({
                "step": current_idx + 1,
                "type": current_challenge["type"],
                "passed_at": round(time.time() - session["created_at"], 2)
            })

            session["current_step"] += 1
            session["step_success_frames"] = 0

            # Check if all challenges completed
            if session["current_step"] >= session["total_steps"]:
                session["completed"] = True
                return True, "All liveness challenges completed successfully!"
            else:
                next_challenge = session["challenges"][session["current_step"]]
                return True, f"Challenge {session['current_step']} passed! Next: {next_challenge['title']}"

        return False, "Holding action..."

    @classmethod
    def mark_spoof(cls, session_id, reason="Presentation attack detected"):
        session = cls._sessions.get(session_id)
        if session:
            session["spoof_detected"] = True
            session["spoof_reason"] = reason

    @classmethod
    def invalidate(cls, session_id):
        if session_id in cls._sessions:
            del cls._sessions[session_id]

    @classmethod
    def cleanup_expired(cls):
        """Purges old expired sessions."""
        now = time.time()
        expired_keys = [k for k, v in cls._sessions.items() if now > v.get("expires_at", 0)]
        for k in expired_keys:
            del cls._sessions[k]
