import cv2
import numpy as np
from config import (
    LIVENESS_BLUR_THRESHOLD,
    SPOOF_FFT_THRESHOLD,
    SPOOF_COLOR_VAR_THRESHOLD,
    SPOOF_GLARE_THRESHOLD
)

class AntiSpoofingEngine:
    """
    BioShield AI Multi-Layer Anti-Spoofing Detection Engine.
    Detects presentation attacks:
    - 2D Paper photo prints (flat surface, extreme blurriness, halftone ink)
    - Digital screen replays (smartphones, tablets, LCD monitors exhibiting moiré patterns & backlight reflection)
    """

    @staticmethod
    def calculate_laplacian_variance(face_crop):
        """
        Computes edge sharpness and blurriness using Laplacian operator.
        Extreme blur (< 4.0) indicates out-of-focus printed paper or flat low-resolution photo.
        Note: Natural head motion during challenge actions can produce temporary motion blur.
        """
        if face_crop is None or face_crop.size == 0:
            return 0.0
        gray = cv2.cvtColor(face_crop, cv2.COLOR_BGR2GRAY) if len(face_crop.shape) == 3 else face_crop
        return float(cv2.Laplacian(gray, cv2.CV_64F).var())

    @staticmethod
    def calculate_fft_moiré_score(face_crop):
        """
        Computes 2D Fast Fourier Transform (FFT) frequency spectrum.
        Detects repetitive subpixel pixel grids and moiré artifacts produced by LCD/OLED displays.
        Standard webcams with JPEG compression yield scores around 4.0 - 6.5.
        Actual digital screen replays produce prominent peaks exceeding 8.0+.
        """
        if face_crop is None or face_crop.size == 0:
            return 0.0
        
        # Resize to fixed dimension for consistent frequency domain normalization
        resized = cv2.resize(face_crop, (128, 128))
        gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY) if len(resized.shape) == 3 else resized

        # Compute 2D Discrete Fourier Transform
        f = np.fft.fft2(gray)
        fshift = np.fft.fftshift(f)
        magnitude_spectrum = np.abs(fshift)

        h, w = gray.shape
        cy, cx = h // 2, w // 2

        # Create low-frequency center mask and high-frequency outer ring mask
        y, x = np.ogrid[:h, :w]
        dist_from_center = np.sqrt((x - cx)**2 + (y - cy)**2)

        # Center low frequencies (radius <= 20)
        low_freq_mask = dist_from_center <= 20
        # High frequencies (radius between 34 and 58)
        high_freq_mask = (dist_from_center >= 34) & (dist_from_center <= 58)

        low_energy = np.mean(magnitude_spectrum[low_freq_mask]) + 1e-6
        high_energy = np.mean(magnitude_spectrum[high_freq_mask])

        # Ratio of high-frequency energy to low-frequency energy
        ratio = (high_energy / low_energy) * 100.0
        return float(ratio)

    @staticmethod
    def calculate_color_chrominance_diversity(face_crop):
        """
        Analyzes color distribution in YCrCb color space.
        Real human skin contains natural blood flow and warm chrominance variance.
        Monochrome paper prints or heavily washed-out copies show flat chrominance (< 2.0).
        """
        if face_crop is None or face_crop.size == 0:
            return 0.0
        
        ycrcb = cv2.cvtColor(face_crop, cv2.COLOR_BGR2YCrCb)
        _, cr, cb = cv2.split(ycrcb)

        std_cr = np.std(cr)
        std_cb = np.std(cb)
        diversity = float((std_cr + std_cb) / 2.0)
        return diversity

    @staticmethod
    def calculate_screen_glare_index(face_crop):
        """
        Detects unnatural specular reflections characteristic of phone/tablet glass screens.
        """
        if face_crop is None or face_crop.size == 0:
            return 0.0
        
        gray = cv2.cvtColor(face_crop, cv2.COLOR_BGR2GRAY) if len(face_crop.shape) == 3 else face_crop
        hotspots = np.sum(gray > 252)
        total_pixels = gray.size
        glare_ratio = float(hotspots / total_pixels)
        return glare_ratio

    @classmethod
    def evaluate(cls, face_crop, mode="live_stream"):
        """
        Multi-modal presentation attack detection.
        Requires corroborated evidence to declare an attack, eliminating single-frame false alarms
        from normal head movement, low lighting, or webcam JPEG encoding.
        """
        if face_crop is None or face_crop.size == 0:
            return False, 1.0, {"error": "Invalid frame or no face region"}

        laplacian_var = cls.calculate_laplacian_variance(face_crop)
        fft_score = cls.calculate_fft_moiré_score(face_crop)
        color_diversity = cls.calculate_color_chrominance_diversity(face_crop)
        glare_index = cls.calculate_screen_glare_index(face_crop)

        spoof_indicators = 0.0
        reasons = []

        # 1. Screen Replay Attack Corroboration:
        # High Moiré alone can occur from sharp fabric or sensor noise;
        # True screen attacks show high moiré coupled with flat chrominance or glass reflection.
        if fft_score > SPOOF_FFT_THRESHOLD:
            if color_diversity < 2.5 or glare_index > 0.10:
                spoof_indicators += 2.0
                reasons.append(f"Digital screen frequency detected (Moiré: {fft_score:.1f} > {SPOOF_FFT_THRESHOLD})")
            else:
                spoof_indicators += 0.5  # mild signal, insufficient on its own

        # 2. Paper Photo Printout Attack Corroboration:
        # Extreme blur combined with low chrominance diversity indicates paper cutout
        if laplacian_var < LIVENESS_BLUR_THRESHOLD:
            if color_diversity < SPOOF_COLOR_VAR_THRESHOLD:
                spoof_indicators += 2.0
                reasons.append(f"Flat paper photo print detected (Blur: {laplacian_var:.1f}, Chrominance: {color_diversity:.1f})")
            else:
                # Likely normal head rotation motion blur
                spoof_indicators += 0.3

        # 3. Severe Specular Glare Attack (phone glass reflection)
        if glare_index > SPOOF_GLARE_THRESHOLD and fft_score > 6.0:
            spoof_indicators += 1.5
            reasons.append(f"Excessive glass specular reflection ({glare_index*100:.1f}%)")

        spoof_score = min(1.0, round(spoof_indicators / 2.0, 2))
        
        # A confirmed presentation attack requires cumulative corroborated indicators >= 1.5
        is_real = spoof_score < 0.70

        status_text = "GENUINE_LIVE_FACE" if is_real else "SPOOF_PRESENTATION_ATTACK"

        return is_real, spoof_score, {
            "status": status_text,
            "mode": mode,
            "laplacian_variance": round(laplacian_var, 2),
            "fft_moiré_score": round(fft_score, 2),
            "color_diversity": round(color_diversity, 2),
            "glare_index": round(glare_index, 4),
            "reasons": reasons
        }
