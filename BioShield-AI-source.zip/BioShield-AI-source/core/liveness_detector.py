import os
import cv2
import numpy as np
import mediapipe as mp
from mediapipe.tasks.python import vision
from config import (
    MEDIAPIPE_LANDMARKER_MODEL,
    BLINK_THRESHOLD,
    HEAD_YAW_THRESHOLD,
    HEAD_PITCH_THRESHOLD,
    SMILE_THRESHOLD
)

class LivenessDetector:
    """
    BioShield AI Liveness Detection Engine using MediaPipe FaceLandmarker.
    Tracks facial landmarks, eye aspect ratios, blendshapes, and 3D head pose (Yaw, Pitch, Roll).
    """
    _instance = None
    _landmarker = None

    @classmethod
    def get_landmarker(cls):
        """Singleton initialization of the MediaPipe FaceLandmarker."""
        if cls._landmarker is None:
            if not os.path.exists(MEDIAPIPE_LANDMARKER_MODEL):
                raise FileNotFoundError(f"MediaPipe model file not found at {MEDIAPIPE_LANDMARKER_MODEL}")
            
            base_options = mp.tasks.BaseOptions(model_asset_path=MEDIAPIPE_LANDMARKER_MODEL)
            options = vision.FaceLandmarkerOptions(
                base_options=base_options,
                output_face_blendshapes=True,
                output_facial_transformation_matrixes=True,
                num_faces=1
            )
            cls._landmarker = vision.FaceLandmarker.create_from_options(options)
            print("[LivenessDetector] MediaPipe FaceLandmarker initialized successfully.")
        return cls._landmarker

    @staticmethod
    def _extract_head_pose_from_matrix(matrix):
        """
        Extracts Yaw, Pitch, Roll from the 4x4 facial transformation matrix.
        """
        if matrix is None or len(matrix) == 0:
            return 0.0, 0.0, 0.0
        
        M = np.array(matrix).reshape(4, 4)
        R = M[:3, :3]

        # Decompose rotation matrix into Euler angles
        yaw = float(np.degrees(np.arctan2(R[0, 2], R[2, 2])))
        pitch = float(np.degrees(np.arcsin(-np.clip(R[1, 2], -1.0, 1.0))))
        roll = float(np.degrees(np.arctan2(R[1, 0], R[1, 1])))

        return yaw, pitch, roll

    @classmethod
    def analyze_frame(cls, frame_bgr):
        """
        Processes a single video frame.
        Returns:
            dict containing:
                - has_face (bool)
                - bbox (dict: x, y, w, h)
                - face_crop (numpy array)
                - blendshapes (dict of key facial movements)
                - head_pose (dict: yaw, pitch, roll)
                - ear (float: eye aspect ratio)
                - raw_landmarks (list of dicts)
        """
        if frame_bgr is None or frame_bgr.size == 0:
            return {"has_face": False, "error": "Empty frame"}

        h, w = frame_bgr.shape[:2]
        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=frame_rgb)

        landmarker = cls.get_landmarker()
        detection_result = landmarker.detect(mp_image)

        if not detection_result.face_landmarks:
            return {"has_face": False, "message": "No face detected"}

        face_landmarks = detection_result.face_landmarks[0]

        # Calculate bounding box from landmarks
        xs = [lm.x for lm in face_landmarks]
        ys = [lm.y for lm in face_landmarks]

        x_min = max(0, int(min(xs) * w))
        y_min = max(0, int(min(ys) * h))
        x_max = min(w, int(max(xs) * w))
        y_max = min(h, int(max(ys) * h))

        # Add modest padding for face crop
        pad_x = int((x_max - x_min) * 0.12)
        pad_y = int((y_max - y_min) * 0.15)
        crop_x1 = max(0, x_min - pad_x)
        crop_y1 = max(0, y_min - pad_y)
        crop_x2 = min(w, x_max + pad_x)
        crop_y2 = min(h, y_max + pad_y)

        face_crop = frame_bgr[crop_y1:crop_y2, crop_x1:crop_x2].copy()

        # Extract blendshapes dictionary
        blendshapes = {}
        if detection_result.face_blendshapes:
            for cat in detection_result.face_blendshapes[0]:
                blendshapes[cat.category_name] = round(float(cat.score), 4)

        # Extract Head Pose (Euler angles)
        yaw, pitch, roll = 0.0, 0.0, 0.0
        if detection_result.facial_transformation_matrixes:
            yaw, pitch, roll = cls._extract_head_pose_from_matrix(
                detection_result.facial_transformation_matrixes[0]
            )

        # Blink scores from high-accuracy blendshapes
        blink_left = blendshapes.get("eyeBlinkLeft", 0.0)
        blink_right = blendshapes.get("eyeBlinkRight", 0.0)
        blink_avg = round((blink_left + blink_right) / 2.0, 4)

        # Smile score
        smile_left = blendshapes.get("mouthSmileLeft", 0.0)
        smile_right = blendshapes.get("mouthSmileRight", 0.0)
        smile_avg = round((smile_left + smile_right) / 2.0, 4)

        return {
            "has_face": True,
            "bbox": {
                "x": x_min,
                "y": y_min,
                "w": x_max - x_min,
                "h": y_max - y_min
            },
            "face_crop": face_crop,
            "head_pose": {
                "yaw": round(yaw, 1),
                "pitch": round(pitch, 1),
                "roll": round(roll, 1)
            },
            "blendshapes": {
                "blink_score": blink_avg,
                "smile_score": smile_avg,
                "jaw_open": blendshapes.get("jawOpen", 0.0)
            }
        }

    @staticmethod
    def verify_action(action_type, analysis_data):
        """
        Validates if the user is actively performing the requested challenge action.
        action_type can be:
            - 'blink': User closed eyes
            - 'turn_left': User rotated head to their left (yaw < -HEAD_YAW_THRESHOLD)
            - 'turn_right': User rotated head to their right (yaw > HEAD_YAW_THRESHOLD)
            - 'tilt_up': User tilted head up (pitch > HEAD_PITCH_THRESHOLD)
            - 'smile': User smiled (smile_score > SMILE_THRESHOLD)
        """
        if not analysis_data or not analysis_data.get("has_face"):
            return False, 0.0, "Face not centered in frame"

        head_pose = analysis_data["head_pose"]
        blendshapes = analysis_data["blendshapes"]
        yaw = head_pose["yaw"]
        pitch = head_pose["pitch"]

        if action_type == "blink":
            score = blendshapes["blink_score"]
            passed = score >= BLINK_THRESHOLD
            msg = "Blink detected!" if passed else f"Blink your eyes (Score: {score:.2f}/{BLINK_THRESHOLD})"
            return passed, score, msg

        elif action_type == "turn_left":
            score = abs(yaw)
            passed_left = (yaw < -HEAD_YAW_THRESHOLD) or (yaw > HEAD_YAW_THRESHOLD)
            msg = "Head turn detected!" if passed_left else f"Turn head left (Angle: {abs(yaw):.1f}° / {HEAD_YAW_THRESHOLD}°)"
            return passed_left, score, msg

        elif action_type == "turn_right":
            score = abs(yaw)
            passed_right = (yaw > HEAD_YAW_THRESHOLD) or (yaw < -HEAD_YAW_THRESHOLD)
            msg = "Head turn detected!" if passed_right else f"Turn head right (Angle: {abs(yaw):.1f}° / {HEAD_YAW_THRESHOLD}°)"
            return passed_right, score, msg

        elif action_type == "tilt_up":
            score = pitch
            passed = pitch > HEAD_PITCH_THRESHOLD
            msg = "Upward tilt detected!" if passed else f"Tilt head upward (Pitch: {pitch:.1f}°)"
            return passed, score, msg

        elif action_type == "smile":
            score = blendshapes["smile_score"]
            passed = score >= SMILE_THRESHOLD
            msg = "Smile detected!" if passed else f"Smile naturally (Score: {score:.2f}/{SMILE_THRESHOLD})"
            return passed, score, msg

        return False, 0.0, "Unknown challenge action"
