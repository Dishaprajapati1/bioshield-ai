import os
import tempfile
import secrets

# Base directories
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
MODELS_DIR = os.path.join(BASE_DIR, "models")
STATIC_DIR = os.path.join(BASE_DIR, "static")
UPLOAD_PROFILES_DIR = os.path.join(STATIC_DIR, "uploads", "profiles")
UPLOAD_LOGS_DIR = os.path.join(STATIC_DIR, "uploads", "logs")
DATABASE_PATH = os.path.join(BASE_DIR, "database", "bioshield.db")

# Ensure required upload directories exist
os.makedirs(UPLOAD_PROFILES_DIR, exist_ok=True)
os.makedirs(UPLOAD_LOGS_DIR, exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, "database"), exist_ok=True)

# Set environment variables for DeepFace & Matplotlib to avoid Windows permission restrictions
os.environ["DEEPFACE_HOME"] = MODELS_DIR
os.environ["MPLCONFIGDIR"] = tempfile.gettempdir()
os.environ["PYTHONIOENCODING"] = "utf-8"

# Model paths
MEDIAPIPE_LANDMARKER_MODEL = os.path.join(MODELS_DIR, "face_landmarker.task")
DEEPFACE_MODEL_NAME = "Facenet512"

# Robust Anti-Spoofing Thresholds (Calibrated to prevent false positives from motion blur and JPEG compression)
FACE_RECOGNITION_THRESHOLD = 0.38  # Cosine distance threshold (lower = stricter match)
LIVENESS_BLUR_THRESHOLD = 4.0      # Only flag extreme zero-texture / totally out-of-focus prints (< 4.0)
SPOOF_FFT_THRESHOLD = 8.0          # True screen subpixel moiré produces > 8.0; JPEG webcam compression stays < 6.5
SPOOF_COLOR_VAR_THRESHOLD = 2.0    # Monochrome/grayscale paper copies drop below 2.0
SPOOF_GLARE_THRESHOLD = 0.20       # Over 20% pure glass reflection hotspots

# Liveness Action Thresholds
BLINK_THRESHOLD = 0.38             # Blendshape eyeBlink score
HEAD_YAW_THRESHOLD = 15.0          # Degrees of yaw for left/right head turn
HEAD_PITCH_THRESHOLD = 12.0        # Degrees of pitch for tilt up/down
SMILE_THRESHOLD = 0.35             # Mouth smile blendshape score

# Challenge-Response Configuration
CHALLENGE_TIMEOUT_SECONDS = 18     # Max seconds allowed to complete randomized challenges
DEFAULT_CHALLENGE_COUNT = 2        # Number of randomized challenges per session

# Multi-frame attack confirmation (prevents false alerts on single-frame motion blur during head turns)
SPOOF_CONSECUTIVE_FRAMES_REQUIRED = 3

# Flask Settings
SECRET_KEY = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
DEBUG = os.environ.get("DEBUG", "false").strip().lower() in {"1", "true", "yes"}
HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", "5000"))
