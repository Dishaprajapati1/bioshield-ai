import os
import sys
import json
import time
import cv2
import numpy as np

# Ensure project root in sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from config import UPLOAD_PROFILES_DIR, UPLOAD_LOGS_DIR
from database.db import init_db, get_db_connection
from database.models import UserModel, SecurityLogModel, TaskModel
from core.face_recognition import FaceRecognitionEngine

def generate_sample_face(name="Demo User"):
    """
    Creates a clean synthetic biometric face portrait image for demo seeding.
    """
    canvas = np.full((320, 320, 3), (28, 22, 18), dtype=np.uint8)
    
    # Head contour (oval)
    cv2.ellipse(canvas, (160, 160), (90, 120), 0, 0, 360, (195, 215, 235), -1) # skin tone
    
    # Hair
    cv2.ellipse(canvas, (160, 95), (96, 65), 0, 0, 180, (40, 30, 25), -1)
    
    # Eyes
    cv2.circle(canvas, (125, 145), 14, (255, 255, 255), -1)
    cv2.circle(canvas, (195, 145), 14, (255, 255, 255), -1)
    cv2.circle(canvas, (125, 145), 7, (70, 50, 30), -1)
    cv2.circle(canvas, (195, 145), 7, (70, 50, 30), -1)

    # Eyebrows
    cv2.line(canvas, (110, 128), (140, 125), (40, 30, 25), 3)
    cv2.line(canvas, (180, 125), (210, 128), (40, 30, 25), 3)

    # Nose
    cv2.line(canvas, (160, 145), (155, 180), (160, 180, 200), 2)
    cv2.line(canvas, (155, 180), (165, 180), (160, 180, 200), 2)

    # Gentle smile
    cv2.ellipse(canvas, (160, 210), (32, 16), 0, 0, 180, (80, 80, 170), 3)

    return canvas

def seed():
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()

    # Clear existing demo entries if any
    cursor.execute("DELETE FROM users WHERE user_id = 'DEMO-0001'")
    conn.commit()

    print("[Seed] Generating demo biometric profile...")
    face_img = generate_sample_face("Demo User")
    profile_filename = "user_DEMO-0001_demo.jpg"
    profile_path = os.path.join(UPLOAD_PROFILES_DIR, profile_filename)
    cv2.imwrite(profile_path, face_img)
    relative_photo_url = f"/static/uploads/profiles/{profile_filename}"

    # Generate real embedding from the generated face
    embedding = FaceRecognitionEngine.extract_embedding(face_img)
    if embedding is None:
        # Fallback to normalized pseudo-random vector
        vec = np.random.randn(512).astype(np.float32)
        embedding = vec / np.linalg.norm(vec)

    UserModel.create(
        user_id="DEMO-0001",
        full_name="Demo User",
        email="demo.user@example.com",
        department="Example Lab",
        role="Demo User",
        photo_path=relative_photo_url,
        embedding=embedding
    )
    print("[Seed] Registered user: DEMO-0001 (Demo User)")

    # Seed realistic audit snapshots & logs
    sample_logs = [
        {
            "user_id": "DEMO-0001",
            "user_name": "Demo User",
            "status": "GRANTED",
            "reason": "Biometric Match Confirmed (Cosine Dist: 0.185)",
            "conf": 94.8,
            "liveness": 1.0,
            "spoof": 0.04
        },
        {
            "user_id": "UNKNOWN",
            "user_name": "Unidentified Attacker",
            "status": "SPOOF_DETECTED",
            "reason": "Spoof Attack Detected: Digital screen frequency detected (Moiré: 3.42); Specular reflection glare",
            "conf": 0.0,
            "liveness": 0.2,
            "spoof": 0.88
        },
        {
            "user_id": "DEMO-0001",
            "user_name": "Demo User",
            "status": "GRANTED",
            "reason": "Biometric Match Confirmed (Cosine Dist: 0.204)",
            "conf": 92.5,
            "liveness": 1.0,
            "spoof": 0.05
        },
        {
            "user_id": "UNKNOWN",
            "user_name": "Unidentified / Attacker",
            "status": "SPOOF_DETECTED",
            "reason": "Spoof Attack Detected: Image blur detected (Var: 32.4 < 60.0); Printed photo paper detected",
            "conf": 0.0,
            "liveness": 0.1,
            "spoof": 0.95
        },
        {
            "user_id": "UNKNOWN",
            "user_name": "Unidentified Person",
            "status": "LIVENESS_FAILED",
            "reason": "Authentication aborted: Liveness challenge incomplete (Head turn timeout)",
            "conf": 0.0,
            "liveness": 0.3,
            "spoof": 0.12
        },
        {
            "user_id": "UNKNOWN",
            "user_name": "Unrecognized Person",
            "status": "DENIED",
            "reason": "Unrecognized Face (Best Dist: 0.582 > 0.380)",
            "conf": 38.2,
            "liveness": 1.0,
            "spoof": 0.06
        }
    ]

    for item in sample_logs:
        snap_name = f"audit_seed_{item['status'].lower()}_{int(time.time())}.jpg"
        snap_path = os.path.join(UPLOAD_LOGS_DIR, snap_name)
        cv2.imwrite(snap_path, face_img)
        snap_url = f"/static/uploads/logs/{snap_name}"

        SecurityLogModel.log(
            user_id=item["user_id"],
            user_name=item["user_name"],
            status=item["status"],
            reason=item["reason"],
            confidence_score=item["conf"],
            liveness_score=item["liveness"],
            spoof_score=item["spoof"],
            snapshot_path=snap_url,
            ip_address="203.0.113.10"
        )

    print("[Seed] Seeded security audit ledger records.")

    # Seed employee operational tasks for DEMO-0001
    cursor.execute("DELETE FROM tasks WHERE user_id = 'DEMO-0001'")
    conn.commit()

    demo_tasks = [
        {
            "task_id": "TSK-101",
            "title": "Review Biometric Adversarial Attack Defense",
            "description": "Analyze latest anti-spoofing research papers on multi-spectral 2D-FFT and depth variance.",
            "priority": "CRITICAL",
            "due_date": "Today, 17:00"
        },
        {
            "task_id": "TSK-102",
            "title": "Calibrate Moiré Frequency Filters on 4K OLED Displays",
            "description": "Verify high-frequency ratio thresholds against recent iPad Pro and Samsung OLED mobile screens.",
            "priority": "HIGH",
            "due_date": "Today, 19:30"
        },
        {
            "task_id": "TSK-103",
            "title": "Perform Security Audit on Sector 4 Server Gateway",
            "description": "Inspect perimeter firewall logs and check for unauthorized SSH port probing.",
            "priority": "MEDIUM",
            "due_date": "Tomorrow"
        },
        {
            "task_id": "TSK-104",
            "title": "Compile Weekly Biometric Compliance Report",
            "description": "Export CSV audit ledger and present FAR/FRR statistics to cybersecurity director.",
            "priority": "LOW",
            "due_date": "Friday"
        }
    ]

    for t in demo_tasks:
        TaskModel.create(
            task_id=t["task_id"],
            user_id="DEMO-0001",
            title=t["title"],
            description=t["description"],
            priority=t["priority"],
            due_date=t["due_date"]
        )

    print("[Seed] Seeded operational tasks for Demo User.")
    conn.close()

if __name__ == "__main__":
    seed()
